@echo off
chcp 65001 >nul
title HB Roaster Wireless Bridge

echo ========================================================
echo   HB Roaster & Artisan Wireless Bridge (Windows) ☕️
echo ========================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到系统 Python。
    echo 请先前往 https://www.python.org/downloads/ 安装 Python 3.9+
    echo 安装时务必勾选 "Add Python to PATH"！
    echo.
    pause
    exit /b 1
)

echo [1/2] 正在检查依赖组件...
pip install -r requirements_windows.txt >nul 2>&1

echo [2/2] 正在启动 HB Roaster 图形客户端...
python hb_windows_app.py
