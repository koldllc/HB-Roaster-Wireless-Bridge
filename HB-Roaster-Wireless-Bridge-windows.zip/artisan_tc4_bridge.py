"""
Artisan Protocol Bridge (Arduino TC4 Serial & WebSocket).
Supports:
  - Unix / macOS Virtual Serial Port (PTY emulating Arduino TC4 at /tmp/hb_roaster)
  - Windows COM Port (e.g. COM11 paired with COM10 via com0com, emulating Arduino TC4)
  - Raw TCP Socket Bridge (TC4 over TCP)
  - Pure Python RFC 6455 WebSocket Bridge (Artisan zero-driver WebSocket mode)
"""

from __future__ import annotations
import os
import sys
import json
import socket
import select
import struct
import base64
import hashlib
import threading
import time
import logging
from typing import Optional, Tuple

from hb_client import HBClient

try:
    import pty
    import tty
    HAS_PTY = True
except ImportError:
    pty = None
    tty = None
    HAS_PTY = False

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    serial = None
    HAS_SERIAL = False

logger = logging.getLogger("tc4_bridge")


class ArtisanWebSocketBridge:
    """
    Lightweight zero-dependency RFC 6455 WebSocket bridge for Artisan.
    Allows Artisan to stream real-time 4-channel telemetry without any virtual COM drivers on Windows.
    Endpoint: ws://127.0.0.1:<port>/ws
    """
    WS_MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

    def __init__(self, hb_client: HBClient, host: str = "127.0.0.1", port: int = 8088):
        self.hb_client = hb_client
        self.host = host
        self.port = port
        self.last_artisan_poll: float = 0.0
        self.artisan_connected = False
        self._running = False
        self._server_sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None

    def start(self):
        if self._running:
            return
        try:
            self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server_sock.bind((self.host, self.port))
            self._server_sock.listen(5)
            self._server_sock.settimeout(0.5)
            self._running = True
            self._thread = threading.Thread(target=self._accept_loop, name="ArtisanWSThread", daemon=True)
            self._thread.start()
            logger.info("Artisan WebSocket Bridge listening on ws://%s:%d/ws", self.host, self.port)
        except Exception as e:
            logger.warning("Could not bind Artisan WebSocket port %s:%d: %s", self.host, self.port, e)

    def stop(self):
        self._running = False
        if self._server_sock:
            try:
                self._server_sock.close()
            except Exception:
                pass
            self._server_sock = None
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)

    def _accept_loop(self):
        while self._running:
            # Watchdog
            now = time.time()
            if self.last_artisan_poll > 0 and (now - self.last_artisan_poll > 4.0):
                self.artisan_connected = False

            try:
                client_sock, addr = self._server_sock.accept()
            except (socket.timeout, OSError):
                continue
            except Exception:
                break

            client_thread = threading.Thread(
                target=self._handle_client,
                args=(client_sock, addr),
                daemon=True,
                name=f"ArtisanWSClient-{addr[1]}",
            )
            client_thread.start()

    def _handle_client(self, client_sock: socket.socket, addr):
        client_sock.settimeout(1.0)
        try:
            # Perform WebSocket Handshake
            handshake_data = client_sock.recv(4096)
            if not handshake_data:
                client_sock.close()
                return

            req_text = handshake_data.decode("utf-8", "ignore")
            sec_key = None
            for line in req_text.splitlines():
                if line.lower().startswith("sec-websocket-key:"):
                    sec_key = line.split(":", 1)[1].strip()
                    break

            if not sec_key:
                client_sock.sendall(b"HTTP/1.1 400 Bad Request\r\n\r\n")
                client_sock.close()
                return

            accept_val = base64.b64encode(
                hashlib.sha1((sec_key + self.WS_MAGIC).encode("utf-8")).digest()
            ).decode("utf-8")

            resp = (
                "HTTP/1.1 101 Switching Protocols\r\n"
                "Upgrade: websocket\r\n"
                "Connection: Upgrade\r\n"
                f"Sec-WebSocket-Accept: {accept_val}\r\n\r\n"
            )
            client_sock.sendall(resp.encode("utf-8"))
            logger.info("Artisan WebSocket connected from %s", addr)

            # Frame read loop
            client_sock.settimeout(0.2)
            in_buf = bytearray()

            while self._running:
                now = time.time()
                if self.last_artisan_poll > 0 and (now - self.last_artisan_poll > 4.0):
                    self.artisan_connected = False

                try:
                    data = client_sock.recv(2048)
                    if not data:
                        break
                    in_buf.extend(data)
                except socket.timeout:
                    pass
                except OSError:
                    break

                while True:
                    frame, consumed = self._decode_frame(in_buf)
                    if not frame:
                        break
                    del in_buf[:consumed]
                    opcode, payload = frame

                    if opcode == 0x8:  # Close
                        client_sock.sendall(self._encode_frame(b"", opcode=0x8))
                        return
                    elif opcode == 0x9:  # Ping
                        client_sock.sendall(self._encode_frame(payload, opcode=0xA))
                    elif opcode == 0x1:  # Text frame
                        text = payload.decode("utf-8", "ignore").strip()
                        if text:
                            self._handle_artisan_json(client_sock, text)

        except Exception as e:
            logger.debug("Artisan WS client disconnected: %s", e)
        finally:
            try:
                client_sock.close()
            except Exception:
                pass

    def _handle_artisan_json(self, client_sock: socket.socket, text: str):
        try:
            req = json.loads(text)
        except Exception:
            return

        if not isinstance(req, dict):
            return

        cmd = req.get("command") or req.get("cmd") or ""
        msg_id = req.get("id")

        self.last_artisan_poll = time.time()
        self.artisan_connected = True

        # Data polling request from Artisan
        if cmd == "getData" or not cmd:
            snap = self.hb_client.temperature_snapshot()
            data_dict = {}
            if snap is not None:
                ex, ini, bt, et = snap
                data_dict = {
                    "BT": round(bt, 1),
                    "ET": round(et, 1),
                    "Inlet": round(ini, 1),
                    "Exhaust": round(ex, 1),
                }
            resp_dict = {"data": data_dict}
            if msg_id is not None:
                resp_dict["id"] = msg_id
            client_sock.sendall(self._encode_frame(json.dumps(resp_dict).encode("utf-8")))

        elif cmd == "getBT":
            snap = self.hb_client.temperature_snapshot()
            val = round(snap[2], 1) if snap else -1.0
            resp_dict = {"data": {"BT": val}}
            if msg_id is not None:
                resp_dict["id"] = msg_id
            client_sock.sendall(self._encode_frame(json.dumps(resp_dict).encode("utf-8")))

        elif cmd == "getET":
            snap = self.hb_client.temperature_snapshot()
            val = round(snap[3], 1) if snap else -1.0
            resp_dict = {"data": {"ET": val}}
            if msg_id is not None:
                resp_dict["id"] = msg_id
            client_sock.sendall(self._encode_frame(json.dumps(resp_dict).encode("utf-8")))

        # Command requests from Artisan sliders / buttons
        elif "heater" in cmd.lower() or "ot1" in cmd.lower():
            val = float(req.get("value", 0))
            try:
                self.hb_client.set_heat(val > 0)
            except Exception:
                pass
            client_sock.sendall(self._encode_frame(b'{"status": "ok"}'))

        elif "fan" in cmd.lower() or "ot2" in cmd.lower():
            val = float(req.get("value", 0))
            try:
                stir = self.hb_client.stir_on or False
                self.hb_client.set_cooling(stir=stir, fan=(val > 0))
            except Exception:
                pass
            client_sock.sendall(self._encode_frame(b'{"status": "ok"}'))

        elif "stir" in cmd.lower() or "io3" in cmd.lower():
            val = float(req.get("value", 0))
            try:
                fan = self.hb_client.fan_on or False
                self.hb_client.set_cooling(stir=(val > 0), fan=fan)
            except Exception:
                pass
            client_sock.sendall(self._encode_frame(b'{"status": "ok"}'))

    @staticmethod
    def _encode_frame(payload: bytes, opcode: int = 0x1) -> bytes:
        length = len(payload)
        b0 = 0x80 | (opcode & 0x0F)
        if length <= 125:
            header = bytes([b0, length])
        elif length <= 65535:
            header = bytes([b0, 126]) + struct.pack(">H", length)
        else:
            header = bytes([b0, 127]) + struct.pack(">Q", length)
        return header + payload

    @staticmethod
    def _decode_frame(data: bytearray) -> Tuple[Optional[Tuple[int, bytes]], int]:
        if len(data) < 2:
            return None, 0
        b0 = data[0]
        b1 = data[1]
        opcode = b0 & 0x0F
        is_masked = bool(b1 & 0x80)
        payload_len = b1 & 0x7F
        offset = 2

        if payload_len == 126:
            if len(data) < 4:
                return None, 0
            payload_len = struct.unpack(">H", data[2:4])[0]
            offset = 4
        elif payload_len == 127:
            if len(data) < 10:
                return None, 0
            payload_len = struct.unpack(">Q", data[2:10])[0]
            offset = 10

        mask_key = None
        if is_masked:
            if len(data) < offset + 4:
                return None, 0
            mask_key = data[offset : offset + 4]
            offset += 4

        if len(data) < offset + payload_len:
            return None, 0

        payload = bytearray(data[offset : offset + payload_len])
        if is_masked and mask_key:
            for i in range(len(payload)):
                payload[i] ^= mask_key[i % 4]

        total_consumed = offset + payload_len
        return (opcode, bytes(payload)), total_consumed


class ArtisanTC4Bridge:
    def __init__(
        self,
        hb_client: HBClient,
        symlink_path: str = "/tmp/hb_roaster",
        ambient_temp: float = 25.0,
        enable_websocket: bool = True,
        ws_port: int = 8088,
    ):
        self.hb_client = hb_client
        self.ambient_temp = ambient_temp
        self.active_chan = "3400"
        self.last_artisan_poll: float = 0.0
        self._artisan_connected = False

        # Port / transport configuration
        raw_path = symlink_path.strip()
        self.raw_target = raw_path
        self.is_windows = sys.platform == "win32"

        # Determine transport mode: 'com', 'tcp', or 'pty'
        if raw_path.upper().startswith("COM") or raw_path.startswith("\\\\.\\COM"):
            self.mode = "com"
            self.symlink_path = raw_path
        elif raw_path.startswith("tcp://") or raw_path.startswith("tcp:"):
            self.mode = "tcp"
            self.symlink_path = raw_path
        elif not HAS_PTY:
            # On Windows without PTY, default to COM port mode (e.g. COM11)
            self.mode = "com"
            self.symlink_path = raw_path if raw_path.upper().startswith("COM") else "COM11"
        else:
            self.mode = "pty"
            self.symlink_path = os.path.abspath(os.path.expanduser(raw_path))

        # PTY resources (macOS / Linux)
        self._master_fd: Optional[int] = None
        self._slave_fd: Optional[int] = None
        self._slave_name: Optional[str] = None

        # COM resources (Windows)
        self._serial_port = None

        # TCP resources
        self._tcp_server: Optional[socket.socket] = None

        # WebSocket Bridge (Always available on all platforms)
        self.enable_websocket = enable_websocket
        self.ws_bridge: Optional[ArtisanWebSocketBridge] = None
        if enable_websocket:
            self.ws_bridge = ArtisanWebSocketBridge(hb_client, port=ws_port)

        self._running = False
        self._thread: Optional[threading.Thread] = None

    @property
    def artisan_connected(self) -> bool:
        """True if either serial port, TCP, or WebSocket has polled recently."""
        ws_conn = bool(self.ws_bridge and self.ws_bridge.artisan_connected)
        return self._artisan_connected or ws_conn

    @artisan_connected.setter
    def artisan_connected(self, value: bool):
        self._artisan_connected = value

    def start(self):
        """Starts the configured bridge mode and optional WebSocket bridge."""
        if self._running:
            return

        self._running = True

        if self.ws_bridge:
            self.ws_bridge.start()

        if self.mode == "pty":
            if not HAS_PTY:
                logger.warning("PTY not available on this platform; cannot create virtual PTY.")
                return

            master, slave = pty.openpty()
            self._master_fd = master
            self._slave_fd = slave
            self._slave_name = os.ttyname(slave)

            tty.setraw(slave)

            try:
                self._update_symlink(self._slave_name)
            except Exception:
                os.close(master)
                os.close(slave)
                self._master_fd = self._slave_fd = None
                raise

            logger.info(
                "Created virtual serial port at %s (slave: %s)",
                self.symlink_path,
                self._slave_name,
            )
            self._thread = threading.Thread(target=self._run_loop, name="TC4BridgeThread", daemon=True)
            self._thread.start()

        elif self.mode == "com":
            logger.info("Starting TC4 Serial Bridge on Windows port %s", self.symlink_path)
            self._thread = threading.Thread(target=self._run_com_loop, name="TC4ComThread", daemon=True)
            self._thread.start()

        elif self.mode == "tcp":
            logger.info("Starting TC4 TCP Socket Bridge on %s", self.symlink_path)
            self._thread = threading.Thread(target=self._run_tcp_loop, name="TC4TcpThread", daemon=True)
            self._thread.start()

    def stop(self):
        """Stops the bridge and cleans up resources."""
        self._running = False
        if self.ws_bridge:
            self.ws_bridge.stop()

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)

        if self._master_fd is not None:
            try:
                os.close(self._master_fd)
            except Exception:
                pass
            self._master_fd = None

        if self._slave_fd is not None:
            try:
                os.close(self._slave_fd)
            except Exception:
                pass
            self._slave_fd = None

        if self._serial_port is not None:
            try:
                self._serial_port.close()
            except Exception:
                pass
            self._serial_port = None

        if self._tcp_server is not None:
            try:
                self._tcp_server.close()
            except Exception:
                pass
            self._tcp_server = None

        if self.mode == "pty":
            self._remove_symlink()
            logger.info("Virtual serial port %s closed.", self.symlink_path)

    def _update_symlink(self, target: str):
        if not HAS_PTY:
            return
        if os.path.lexists(self.symlink_path):
            if not os.path.islink(self.symlink_path):
                raise FileExistsError(f"串口路径已被文件或目录占用: {self.symlink_path}")
            os.unlink(self.symlink_path)
        os.symlink(target, self.symlink_path)

    def _remove_symlink(self):
        if not HAS_PTY:
            return
        try:
            if os.path.islink(self.symlink_path) and os.readlink(self.symlink_path) == self._slave_name:
                os.unlink(self.symlink_path)
        except OSError:
            pass

    def _format_read_response(self) -> bytes:
        snapshot = self.hb_client.temperature_snapshot()
        if snapshot is None:
            return b""
        ex, ini, bt, et = snapshot
        amb = self.ambient_temp
        chan = self.active_chan

        if chan == "3400":
            line = f"{amb:.1f}, {bt:.1f}, {et:.1f}\r\n"
        elif chan == "1200":
            line = f"{amb:.1f}, {ini:.1f}, {ex:.1f}\r\n"
        elif chan == "1300":
            line = f"{amb:.1f}, {ini:.1f}, {bt:.1f}\r\n"
        elif chan == "2400":
            line = f"{amb:.1f}, {ex:.1f}, {et:.1f}\r\n"
        elif chan == "1234":
            line = f"{amb:.1f}, {ex:.1f}, {ini:.1f}, {bt:.1f}, {et:.1f}\r\n"
        else:
            chan_map = {"1": ex, "2": ini, "3": bt, "4": et}
            parts = [f"{amb:.1f}"]
            for ch in chan[:4]:
                if ch in chan_map:
                    parts.append(f"{chan_map[ch]:.1f}")
                elif ch == "0":
                    parts.append("0.0")
            line = ", ".join(parts) + "\r\n"

        return line.encode("ascii")

    def _process_command(self, cmd: str) -> bytes:
        cmd = cmd.strip()
        if not cmd:
            return b""

        logger.debug("Artisan command: %s", cmd)

        if cmd.startswith("CHAN;"):
            parts = cmd.split(";", 1)
            chan = parts[1].strip() if len(parts) > 1 else ""
            if len(chan) != 4 or any(ch not in "01234" for ch in chan):
                return b"# CHAN ERROR\r\n"
            self.active_chan = chan
            return b"# CHAN OK\r\n"

        elif cmd.startswith("UNITS;"):
            return b"# UNITS OK\r\n"

        elif cmd.startswith("FILT;"):
            return b"# FILT OK\r\n"

        elif cmd == "READ":
            self.last_artisan_poll = time.time()
            self.artisan_connected = True
            return self._format_read_response()

        elif cmd.startswith("OT1;"):
            try:
                val = float(cmd.split(";", 1)[1])
                self.hb_client.set_heat(val > 0)
            except Exception as error:
                logger.warning("Heater command unconfirmed: %s", error)
                return b"# ERROR\r\n"
            return b"# OT1 OK\r\n"

        elif cmd.startswith("OT2;"):
            try:
                val = float(cmd.split(";", 1)[1])
                stir = self.hb_client.stir_on
                if stir is None:
                    raise RuntimeError("搅拌状态尚未确认")
                self.hb_client.set_cooling(stir=stir, fan=(val > 0))
            except Exception as error:
                logger.warning("Fan command unconfirmed: %s", error)
                return b"# ERROR\r\n"
            return b"# OT2 OK\r\n"

        elif cmd.startswith("IO3;"):
            try:
                val = float(cmd.split(";", 1)[1])
                fan = self.hb_client.fan_on
                if fan is None:
                    raise RuntimeError("风扇状态尚未确认")
                self.hb_client.set_cooling(stir=(val > 0), fan=fan)
            except Exception as error:
                logger.warning("Stir command unconfirmed: %s", error)
                return b"# ERROR\r\n"
            return b"# IO3 OK\r\n"

        else:
            return b"# OK\r\n"

    def _run_loop(self):
        """PTY read loop on POSIX systems."""
        in_buf = bytearray()

        while self._running:
            if self._master_fd is None:
                break

            now = time.time()
            if self.last_artisan_poll > 0 and (now - self.last_artisan_poll > 4.0):
                self.artisan_connected = False

            try:
                r, _, _ = select.select([self._master_fd], [], [], 0.2)
                if not r:
                    continue

                chunk = os.read(self._master_fd, 1024)
                if not chunk:
                    continue

                in_buf.extend(chunk)

                while b"\n" in in_buf or b"\r" in in_buf:
                    nl_pos = -1
                    for idx, b in enumerate(in_buf):
                        if b in (10, 13):
                            nl_pos = idx
                            break
                    if nl_pos == -1:
                        break

                    line_bytes = in_buf[:nl_pos]
                    consume_len = nl_pos + 1
                    while consume_len < len(in_buf) and in_buf[consume_len] in (10, 13):
                        consume_len += 1

                    del in_buf[:consume_len]

                    cmd_str = line_bytes.decode("utf-8", "ignore").strip()
                    if cmd_str:
                        resp = self._process_command(cmd_str)
                        if resp and self._master_fd is not None:
                            os.write(self._master_fd, resp)

            except OSError as e:
                logger.debug("PTY read exception: %s", e)
                time.sleep(0.1)
            except Exception as e:
                logger.error("Unexpected error in PTY loop: %s", e)
                time.sleep(0.1)

    def _run_com_loop(self):
        """Windows Serial COM loop via pyserial."""
        if not HAS_SERIAL:
            logger.error("pyserial is not installed. Run 'pip install pyserial' for COM port support.")
            return

        port_name = self.symlink_path
        while self._running:
            try:
                logger.info("Opening COM port %s (115200 8N1)...", port_name)
                ser = serial.Serial(port=port_name, baudrate=115200, timeout=0.2)
                self._serial_port = ser
                logger.info("COM port %s opened successfully.", port_name)

                in_buf = bytearray()
                while self._running:
                    now = time.time()
                    if self.last_artisan_poll > 0 and (now - self.last_artisan_poll > 4.0):
                        self.artisan_connected = False

                    try:
                        chunk = ser.read(128)
                    except Exception as e:
                        logger.warning("Error reading %s: %s", port_name, e)
                        break

                    if not chunk:
                        continue

                    in_buf.extend(chunk)
                    while b"\n" in in_buf or b"\r" in in_buf:
                        nl_pos = -1
                        for idx, b in enumerate(in_buf):
                            if b in (10, 13):
                                nl_pos = idx
                                break
                        if nl_pos == -1:
                            break

                        line_bytes = in_buf[:nl_pos]
                        consume_len = nl_pos + 1
                        while consume_len < len(in_buf) and in_buf[consume_len] in (10, 13):
                            consume_len += 1
                        del in_buf[:consume_len]

                        cmd_str = line_bytes.decode("utf-8", "ignore").strip()
                        if cmd_str:
                            resp = self._process_command(cmd_str)
                            if resp:
                                ser.write(resp)

                ser.close()
                self._serial_port = None
            except Exception as e:
                if self._running:
                    logger.debug("Waiting for COM port %s (%s)...", port_name, e)
                    for _ in range(20):
                        if not self._running:
                            break
                        time.sleep(0.1)

    def _run_tcp_loop(self):
        """Raw TCP loop for TC4 over network socket."""
        port = 8888
        if ":" in self.symlink_path:
            try:
                port = int(self.symlink_path.split(":")[-1].replace("/", ""))
            except Exception:
                pass

        try:
            self._tcp_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._tcp_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._tcp_server.bind(("127.0.0.1", port))
            self._tcp_server.listen(2)
            self._tcp_server.settimeout(0.5)
            logger.info("TC4 TCP Bridge listening on 127.0.0.1:%d", port)
        except Exception as e:
            logger.error("Failed to bind TC4 TCP Bridge on port %d: %s", port, e)
            return

        while self._running:
            now = time.time()
            if self.last_artisan_poll > 0 and (now - self.last_artisan_poll > 4.0):
                self.artisan_connected = False

            try:
                client, _ = self._tcp_server.accept()
            except (socket.timeout, OSError):
                continue
            except Exception:
                break

            client.settimeout(0.2)
            in_buf = bytearray()
            while self._running:
                try:
                    data = client.recv(512)
                    if not data:
                        break
                    in_buf.extend(data)
                    while b"\n" in in_buf or b"\r" in in_buf:
                        nl_pos = -1
                        for idx, b in enumerate(in_buf):
                            if b in (10, 13):
                                nl_pos = idx
                                break
                        if nl_pos == -1:
                            break

                        line_bytes = in_buf[:nl_pos]
                        consume_len = nl_pos + 1
                        while consume_len < len(in_buf) and in_buf[consume_len] in (10, 13):
                            consume_len += 1
                        del in_buf[:consume_len]

                        cmd_str = line_bytes.decode("utf-8", "ignore").strip()
                        if cmd_str:
                            resp = self._process_command(cmd_str)
                            if resp:
                                client.sendall(resp)
                except socket.timeout:
                    continue
                except OSError:
                    break
            try:
                client.close()
            except Exception:
                pass
