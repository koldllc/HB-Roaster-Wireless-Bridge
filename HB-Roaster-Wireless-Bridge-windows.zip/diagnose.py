#!/usr/bin/env python3
"""
HB Roaster & Artisan Wireless Bridge - Diagnostic Tool
Performs comprehensive hardware, network, and protocol diagnostics.
"""

from __future__ import annotations
import os
import sys
import socket
import struct
import subprocess
import time
from typing import Optional, List, Tuple


def c_green(s: str) -> str: return f"\033[92m{s}\033[0m"
def c_red(s: str) -> str: return f"\033[91m{s}\033[0m"
def c_yellow(s: str) -> str: return f"\033[93m{s}\033[0m"
def c_cyan(s: str) -> str: return f"\033[96m{s}\033[0m"
def c_bold(s: str) -> str: return f"\033[1m{s}\033[0m"


def check_vpn_status() -> Tuple[bool, str]:
    """Checks if a VPN / Proxy like Loon or Clash is active with TUN routing."""
    try:
        if sys.platform == "win32":
            res = subprocess.run(["route", "print"], capture_output=True)
            try:
                stdout_str = res.stdout.decode("utf-8", "ignore")
            except Exception:
                stdout_str = res.stdout.decode("gbk", "ignore")
            for line in stdout_str.splitlines():
                if "0.0.0.0" in line and ("TAP" in line or "Wintun" in line or "Clash" in line):
                    return True, "Windows TUN/TAP"
        else:
            res = subprocess.run(["netstat", "-rn"], capture_output=True, text=True)
            for line in res.stdout.splitlines():
                if "255.255.255.255" in line and "utun" in line:
                    tun_dev = line.strip().split()[-1]
                    return True, tun_dev
                if "default" in line and "utun" in line:
                    tun_dev = line.strip().split()[-1]
                    return True, tun_dev
    except Exception:
        pass
    return False, ""


def get_local_wifi_ip() -> Optional[str]:
    """Gets local primary IPv4 address."""
    try:
        if sys.platform == "darwin":
            res = subprocess.run(["ipconfig", "getifaddr", "en0"], capture_output=True, text=True)
            ip = res.stdout.strip()
            if ip:
                return ip
        # Windows / Linux fallback
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        # Connect to a dummy public IP without sending packets to find local routing IP
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    return None


def probe_udp_discovery(timeout: float = 2.0) -> Optional[Tuple[str, str]]:
    """Probes for roaster on physical en0 via UDP broadcast."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

    if sys.platform == "darwin":
        try:
            if_idx = socket.if_nametoindex("en0")
            IP_BOUND_IF = 25
            sock.setsockopt(socket.IPPROTO_IP, IP_BOUND_IF, struct.pack("I", if_idx))
        except Exception:
            pass

    sock.settimeout(timeout)

    targets = ["255.255.255.255", "192.168.88.255", "192.168.4.1", "192.168.88.88"]
    for t in targets:
        try:
            sock.sendto(b"whereareyou\r\n", (t, 17888))
        except Exception:
            pass

    start = time.time()
    while time.time() - start < timeout:
        try:
            data, (addr, _) = sock.recvfrom(512)
            sock.close()
            return addr, data.decode("utf-8", "ignore").strip()
        except socket.timeout:
            break
        except Exception:
            pass

    sock.close()
    return None


def test_tcp_port(ip: str, port: int = 16888, timeout: float = 1.5) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((ip, port))
        s.close()
        return True
    except Exception:
        return False


def test_serial_port(path: str = "/tmp/hb_roaster") -> Tuple[bool, str]:
    if sys.platform == "win32" or path.upper().startswith("COM"):
        if not path.upper().startswith("COM"):
            path = "COM11"
        try:
            import serial
            s = serial.Serial(path, 115200, timeout=0.1)
            s.close()
            return True, f"正常 (成功打开串口 {path})"
        except ImportError:
            return False, "pyserial 库未安装 (如使用免驱动 WebSocket 模式可忽略)"
        except Exception as e:
            return False, f"无法打开串口 {path}: {e}"

    if not os.path.exists(path):
        return False, "文件不存在 (桥接服务未启动)"
    if not os.path.islink(path):
        return False, "路径存在但非软链接"
    target = os.readlink(path)
    try:
        fd = os.open(path, os.O_RDWR | getattr(os, "O_NOCTTY", 0))
        os.close(fd)
        return True, f"正常 (指向 {target})"
    except Exception as e:
        return False, f"无法打开: {e}"


def run_diagnostics():
    print("\n" + "=" * 62)
    print(c_bold("       HB 烘焙机与 Artisan 无线桥接 - 一键系统诊断"))
    print("=" * 62)

    # 1. Network Interface
    wifi_ip = get_local_wifi_ip()
    print(f"1. 本机 Wi-Fi 网卡 (en0):")
    if wifi_ip:
        print(f"   - 状态: {c_green('已连接')}，IP 地址: {c_cyan(wifi_ip)}")
    else:
        print(f"   - 状态: {c_red('未连接或无 IPv4 地址')}")
        print(f"     {c_yellow('请确认电脑已连接至与烘焙机相同的 Wi-Fi 路由器！')}")

    # 2. VPN / Proxy Check
    is_vpn, tun_dev = check_vpn_status()
    print(f"\n2. 网络代理 / VPN 状态:")
    if is_vpn:
        print(f"   - 检测到 TUN/虚拟网卡: {c_yellow(tun_dev)} (如 Loon, Clash, Surge)")
        print(f"   - 说明: 桥接程序已内置 {c_green('IP_BOUND_IF')} 强制绕过代理路由。")
        print(f"   - 建议: 若遇连接问题，可临时暂停代理的 Enhanced/TUN 模式测试。")
    else:
        print(f"   - 状态: {c_green('无全局 TUN 代理干扰')}")

    # 3. Known Roaster Probes
    print(f"\n3. 烘焙机硬件通信探测:")
    last_ip_file = os.path.expanduser("~/.hb_roaster_last_ip")
    last_ip = None
    if os.path.exists(last_ip_file):
        with open(last_ip_file) as f:
            last_ip = f.read().strip()

    candidate_ips = ["192.168.88.88", "192.168.4.1"]
    if last_ip and last_ip not in candidate_ips:
        candidate_ips.insert(0, last_ip)

    tcp_ok_ip = None
    for cip in candidate_ips:
        sys.stdout.write(f"   - 测试 IP {cip:15s} TCP 端口 16888... ")
        sys.stdout.flush()
        if test_tcp_port(cip, 16888, timeout=1.0):
            print(c_green("通畅 (已响应)"))
            tcp_ok_ip = cip
            break
        else:
            print(c_red("超时未响应"))

    # 4. UDP Broadcast Discovery
    sys.stdout.write(f"   - 正在执行局域网 UDP 广播发现 (端口 17888)... ")
    sys.stdout.flush()
    disc_res = probe_udp_discovery(timeout=2.0)
    if disc_res:
        dev_ip, dev_id = disc_res
        print(c_green(f"成功发现！"))
        print(f"     烘焙机 IP: {c_cyan(dev_ip)} | 硬件识别码: {c_cyan(dev_id)}")
        tcp_ok_ip = dev_ip
    else:
        print(c_yellow("广播未收到回复"))

    # 5. Virtual Serial Port
    print(f"\n4. Artisan 虚拟串口 (/tmp/hb_roaster):")
    sp_ok, sp_msg = test_serial_port("/tmp/hb_roaster")
    if sp_ok:
        print(f"   - 状态: {c_green(sp_msg)}")
    else:
        print(f"   - 状态: {c_yellow(sp_msg)}")

    # Summary
    print("\n" + "=" * 62)
    print(c_bold("【诊断结论与操作建议】"))
    print("=" * 62)
    if tcp_ok_ip:
        print(c_green(f"✔ 烘焙机在线！IP 为: {tcp_ok_ip}"))
        print(f"  建议启动命令: {c_cyan(f'python3 main.py --ip {tcp_ok_ip}')}")
        if sp_ok:
            print(c_green("✔ Artisan 虚拟串口已就绪，可直接在 Artisan 点击 'ON' 开启采集！"))
        else:
            print(f"  提示: 启动 main.py 即可自动建立虚拟串口。")
    else:
        print(c_red("✘ 当前未能与烘焙机建立通信。请按以下步骤快速排查："))
        print(f"  1. {c_bold('机身电源')}：烘焙机机械总电源开关是否开启？")
        print(f"  2. {c_bold('Wi-Fi 指示')}：机器屏幕上的 Wi-Fi 图标是否常亮？")
        print(f"  3. {c_bold('路由器网段')}：电脑是否连在同一个 Wi-Fi (当前电脑 IP 为 {wifi_ip or '未连接'})？")
        print(f"  4. {c_bold('直连模式')}：若机器未连上路由器，手机/电脑搜索是否有热点 {c_cyan('ESP-HB')} (密码 123456789)")
        print(f"     若连接该热点，请使用: {c_cyan('python3 main.py --ip 192.168.4.1')}")

    print("=" * 62 + "\n")


if __name__ == "__main__":
    run_diagnostics()
