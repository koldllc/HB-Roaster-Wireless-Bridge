#!/usr/bin/env python3
"""
HB Roaster & Artisan Wireless Bridge
Bridges HB coffee roasters over Wi-Fi to Artisan via a virtual serial port (PTY) emulating Arduino TC4.
"""

from __future__ import annotations
import argparse
import logging
import os
import signal
import sys
import time

from hb_client import HBClient
from artisan_tc4_bridge import ArtisanTC4Bridge
from web_server import WebServer


def setup_logging(debug: bool = False):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] (%(name)s) %(message)s",
        datefmt="%H:%M:%S",
    )


def print_banner(ip: str | None, pty_path: str, web_port: int, no_web: bool, ws_port: int = 8088):
    print("\n" + "=" * 62)
    print("       HB 烘焙机 · Artisan 无线桥接中间件 (Wireless Bridge)")
    print("=" * 62)
    print(f"  * 烘焙机目标:  {ip if ip else '自动 UDP 广播发现 (端口 17888)'}")
    print(f"  * 串口/COM:    {pty_path}")
    print(f"  * WebSocket:   ws://127.0.0.1:{ws_port}/ws (免驱动极速模式)")
    if not no_web:
        print(f"  * 网页控制台:  http://localhost:{web_port}")
    print("=" * 62)
    print("  [Artisan 快速接入 (二选一)]")
    print("  方案 1 (推荐 · 免驱动):")
    print(f"     Artisan 设备选 'WebSocket'，端口填: ws://127.0.0.1:{ws_port}/ws")
    print("  方案 2 (传统虚拟串口):")
    print(f"     Artisan 设备选 'HB Model S'，端口填: {pty_path}")
    print("=" * 62 + "\n")


def main():
    default_pty = "COM11" if sys.platform == "win32" else "/tmp/hb_roaster"

    parser = argparse.ArgumentParser(
        description="HB Roaster to Artisan Wireless Bridge (Arduino TC4 Emulation)"
    )
    parser.add_argument(
        "--ip",
        type=str,
        default=None,
        help="HB roaster IP address (e.g. 192.168.88.88). If omitted, auto-discovers via UDP.",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=16888,
        help="HB roaster TCP port (default: 16888)",
    )
    parser.add_argument(
        "--pty",
        type=str,
        default=default_pty,
        help=f"Virtual serial / COM port for Artisan (default: {default_pty})",
    )
    parser.add_argument(
        "--ws-port",
        type=int,
        default=8088,
        help="Artisan WebSocket bridge port (default: 8088)",
    )
    parser.add_argument(
        "--no-ws",
        action="store_true",
        help="Disable the embedded Artisan WebSocket bridge",
    )
    parser.add_argument(
        "--ambient",
        type=float,
        default=25.0,
        help="Ambient temperature fallback in °C (default: 25.0)",
    )
    parser.add_argument(
        "--web-port",
        type=int,
        default=8080,
        help="Web dashboard port (default: 8080)",
    )
    parser.add_argument(
        "--no-web",
        action="store_true",
        help="Disable the embedded web dashboard",
    )
    parser.add_argument(
        "--gui",
        action="store_true",
        help="Launch native desktop GUI application",
    )
    parser.add_argument(
        "--cli",
        action="store_true",
        help="Force command-line interface mode",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable verbose debug logging",
    )

    args = parser.parse_args()

    # On Windows, if launched directly without --cli, prefer GUI
    is_windows = sys.platform == "win32"
    if (args.gui or (is_windows and not args.cli)) and not (len(sys.argv) > 1 and args.cli):
        try:
            from hb_windows_app import run_app
            run_app(args)
            return
        except Exception as e:
            logger.warning("Could not launch GUI (%s); falling back to CLI.", e)

    setup_logging(args.debug)
    print_banner(args.ip, args.pty, args.web_port, args.no_web, args.ws_port)

    # Initialize components
    client = HBClient(host=args.ip, port=args.port)
    bridge = ArtisanTC4Bridge(
        hb_client=client,
        symlink_path=args.pty,
        ambient_temp=args.ambient,
        enable_websocket=not args.no_ws,
        ws_port=args.ws_port,
    )
    web = None if args.no_web else WebServer(client, bridge, port=args.web_port)

    running = True

    def sig_handler(sig, frame):
        nonlocal running
        running = False
        raise KeyboardInterrupt

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    client.start()
    bridge.start()
    if web:
        web.start()

    # Main dashboard update loop in console
    try:
        while running:
            time.sleep(1.0)
            if not sys.stdout.isatty() or args.debug:
                # Non-interactive or debug mode, let standard logs flow
                continue

            # Clear line and print compact status line
            conn_str = f"\033[92m已连接 ({client.host})\033[0m" if client.is_connected else "\033[91m未连接 (扫描中)\033[0m"
            art_str = "\033[92m正在采集\033[0m" if bridge.artisan_connected else "\033[90m等待连接\033[0m"
            t_str = f"BT: \033[92m{client.bt:5.1f}°C\033[0m | ET: \033[91m{client.et:5.1f}°C\033[0m | 出风: \033[94m{client.exhaust:5.1f}°C\033[0m | 进风: \033[93m{client.inlet:5.1f}°C\033[0m"

            sys.stdout.write(f"\r[烘焙机: {conn_str}] [Artisan: {art_str}] {t_str} ")
            sys.stdout.flush()

    except KeyboardInterrupt:
        pass
    finally:
        print("\n正在停止无线桥接服务...")
        if web:
            web.stop()
        bridge.stop()
        client.stop()
        print("无线桥接服务已完全退出。")


if __name__ == "__main__":
    main()
