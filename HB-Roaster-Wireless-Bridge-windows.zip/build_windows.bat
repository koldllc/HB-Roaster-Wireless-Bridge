@echo off
chcp 65001 >nul
echo ====================================================
echo   HB Roaster Wireless Bridge - Windows 一键打包脚本
echo ====================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到 Python，请先从 https://www.python.org 安装 Python 3.9+ 并勾选 "Add Python to PATH"。
    pause
    exit /b 1
)

python build_windows.py

echo.
echo ====================================================
echo   打包流程结束，可直接查看 dist\ 目录或 zip 压缩包！
echo ====================================================
pause
