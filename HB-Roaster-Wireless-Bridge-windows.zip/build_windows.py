#!/usr/bin/env python3
"""
Build and package HB Roaster Wireless Bridge for Windows into a standalone .exe
Run on Windows: python build_windows.py
"""

import os
import sys
import shutil
import zipfile
import subprocess

DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(DIR)

APP_NAME = "HB-Roaster-Wireless-Bridge"
EXE_NAME = f"{APP_NAME}.exe"
ZIP_NAME = f"{APP_NAME}-windows.zip"


def check_and_install_dependencies():
    print("📦 正在检查 Windows 打包依赖项...")
    required = ["pyinstaller", "pyserial", "pillow", "pystray"]
    for pkg in required:
        try:
            __import__(pkg)
        except ImportError:
            print(f"   * 正在安装缺失依赖: {pkg}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
    print("✅ 依赖项检查就绪。")


def build_exe():
    print(f"\n🔨 正在使用 PyInstaller 编译 {APP_NAME}...")

    icon_flag = []
    if os.path.exists("AppIcon.ico"):
        icon_flag = ["--icon=AppIcon.ico", "--add-data=AppIcon.ico;."]

    cmd = [
        sys.executable,
        "-m",
        "PyInstaller",
        "--noconfirm",
        "--clean",
        "--onefile",
        "--windowed",
        f"--name={APP_NAME}",
        *icon_flag,
        "hb_windows_app.py",
    ]

    print("执行命令:", " ".join(cmd))
    res = subprocess.run(cmd)
    if res.returncode != 0:
        print("❌ 编译失败，请检查上方日志。")
        sys.exit(res.returncode)

    dist_exe = os.path.join("dist", EXE_NAME)
    if not os.path.exists(dist_exe):
        print(f"❌ 找不到编译输出文件: {dist_exe}")
        sys.exit(1)

    print(f"✅ 编译成功: {dist_exe}")
    return dist_exe


def package_zip(dist_exe):
    print(f"\n📦 正在组装压缩包 {ZIP_NAME}...")
    with zipfile.ZipFile(ZIP_NAME, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(dist_exe, arcname=EXE_NAME)
        if os.path.exists("docs/WINDOWS_SETUP.md"):
            z.write("docs/WINDOWS_SETUP.md", arcname="WINDOWS_SETUP.md")
        if os.path.exists("README.md"):
            z.write("README.md", arcname="README.md")
        if os.path.exists("AppIcon.ico"):
            z.write("AppIcon.ico", arcname="AppIcon.ico")

    size_mb = os.path.getsize(ZIP_NAME) / (1024 * 1024)
    print(f"🎉 打包完成！发布包: {ZIP_NAME} ({size_mb:.2f} MB)")
    print(f"👉 用户可直接解压并双击运行 {EXE_NAME}，无需安装 Python！")


if __name__ == "__main__":
    check_and_install_dependencies()
    dist_exe = build_exe()
    package_zip(dist_exe)
