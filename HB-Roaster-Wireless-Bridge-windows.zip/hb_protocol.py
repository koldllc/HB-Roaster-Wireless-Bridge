"""
HB Roaster Protocol Definitions and Codecs
Supports framing, stream parsing, and data decoding.
"""

from __future__ import annotations
import struct
from enum import IntEnum
from typing import Optional, List, Tuple


class HBDataType(IntEnum):
    HEAT_STATE = 0x00
    COOLING_STATE = 0x01
    TEMPERATURES = 0x02
    WARNING_TEMP = 0x03
    STORED_COUNT = 0x04
    STORED_TEMPS = 0x05
    POWER_STATE = 0x06
    TIMER_STATE = 0x10
    TIMER_VALUE = 0x11
    SSID = 0x20
    PASSWORD = 0x21


class HBFrame:
    START_BYTE = 0x68
    FRAME_END = 0x16
    TERMINATOR = bytes([FRAME_END, 0x0D, 0x0A])

    def __init__(
        self,
        control: int,
        sequence: int = 0,
        data_type: int = 0,
        payload: bytes = b"",
    ):
        self.control = control & 0xFF
        self.sequence = sequence & 0xFF
        self.data_type = data_type & 0xFF
        self.payload = bytes(payload)

    @classmethod
    def read(cls, data_type: int | HBDataType, sequence: int = 0) -> HBFrame:
        return cls(control=0x00, sequence=sequence, data_type=int(data_type), payload=b"")

    @classmethod
    def write(cls, data_type: int | HBDataType, payload: bytes, sequence: int = 0) -> HBFrame:
        return cls(control=0x01, sequence=sequence, data_type=int(data_type), payload=payload)

    @classmethod
    def set_power(cls, on: bool, sequence: int = 0) -> HBFrame:
        return cls.write(HBDataType.POWER_STATE, bytes([255 if on else 0]), sequence)

    @classmethod
    def set_heat(cls, on: bool, sequence: int = 0) -> HBFrame:
        return cls.write(HBDataType.HEAT_STATE, bytes([255 if on else 0]), sequence)

    @classmethod
    def set_cooling(cls, stir: bool, fan: bool, sequence: int = 0) -> HBFrame:
        val = (2 if stir else 0) + (1 if fan else 0)
        return cls.write(HBDataType.COOLING_STATE, bytes([val]), sequence)

    @classmethod
    def set_timer(cls, running: bool, sequence: int = 0) -> HBFrame:
        return cls.write(HBDataType.TIMER_STATE, bytes([0 if running else 1]), sequence)

    def encode(self, append_crlf: bool = True) -> bytes:
        content_len = len(self.payload) + 1
        hdr = bytes([
            self.START_BYTE,
            self.control,
            self.sequence,
            (content_len >> 8) & 0xFF,
            content_len & 0xFF,
            self.data_type,
        ]) + self.payload
        chk = sum(hdr) & 0xFF
        if append_crlf:
            return hdr + bytes([chk, self.FRAME_END, 0x0D, 0x0A])
        else:
            return hdr + bytes([chk, self.FRAME_END])

    @classmethod
    def decode(cls, data: bytes) -> Optional[HBFrame]:
        if len(data) < 8:
            return None
        if data[0] != cls.START_BYTE:
            return None

        content_len = (data[3] << 8) | data[4]
        if content_len < 1:
            return None

        checksum_idx = 5 + content_len
        frame_end_idx = checksum_idx + 1

        if len(data) <= frame_end_idx:
            return None
        if data[frame_end_idx] != cls.FRAME_END:
            return None

        expected_chk = sum(data[:checksum_idx]) & 0xFF
        if data[checksum_idx] != expected_chk:
            return None

        control = data[1]
        sequence = data[2]
        data_type = data[5]
        payload = data[6:checksum_idx]

        return cls(control=control, sequence=sequence, data_type=data_type, payload=payload)

    def temperatures(self) -> Optional[Tuple[float, float, float, float]]:
        """
        Decodes temperatures payload (8 bytes):
        raw[0:2] -> exhaust / outlet (出风)
        raw[2:4] -> inlet (进风)
        raw[4:6] -> bean temp BT (豆温)
        raw[6:8] -> environment temp ET (环境/鼓风)
        """
        if self.data_type != HBDataType.TEMPERATURES or len(self.payload) != 8:
            return None
        t0, t1, t2, t3 = struct.unpack(">HHHH", self.payload)
        return (t0 / 10.0, t1 / 10.0, t2 / 10.0, t3 / 10.0)

    @property
    def is_response(self) -> bool:
        return bool(self.control & 0x80)

    def command_response(self) -> HBFrame:
        return HBFrame(
            control=self.control | 0x80,
            sequence=self.sequence,
            data_type=self.data_type,
            payload=self.payload,
        )


class HBStreamDecoder:
    """
    Tolerant streaming frame parser for the HB roaster TCP stream.
    Finds start byte 0x68, calculates frame length, verifies checksum and 0x16 tail.
    Handles optional trailing \r\n.
    """

    def __init__(self):
        self.buffer = bytearray()

    def append(self, data: bytes) -> List[HBFrame]:
        self.buffer.extend(data)
        frames: List[HBFrame] = []

        while True:
            # Locate start byte
            start_idx = self.buffer.find(bytes([HBFrame.START_BYTE]))
            if start_idx == -1:
                self.buffer.clear()
                break
            if start_idx > 0:
                del self.buffer[:start_idx]

            # Need at least 5 bytes to read content length
            if len(self.buffer) < 5:
                break

            content_len = (self.buffer[3] << 8) | self.buffer[4]
            if content_len < 1:
                # Corrupted header, skip start byte and try again
                del self.buffer[0]
                continue

            control = self.buffer[1]
            if control == 0x00 and content_len != 1:
                del self.buffer[0]
                continue
            if control != 0x00 and len(self.buffer) >= 6:
                expected = {HBDataType.TEMPERATURES: 9, HBDataType.HEAT_STATE: 2,
                            HBDataType.COOLING_STATE: 2, HBDataType.POWER_STATE: 2,
                            HBDataType.TIMER_STATE: 2}.get(self.buffer[5])
                if expected is not None and content_len != expected and not (control == 0x81 and content_len == 1):
                    del self.buffer[0]
                    continue

            # Core frame length = 5 (header) + content_len + 1 (chk) + 1 (tail 0x16) = content_len + 7
            core_len = content_len + 7
            if len(self.buffer) < core_len:
                break

            candidate = bytes(self.buffer[:core_len])
            total_consume = core_len

            # Check if followed by \r\n
            if len(self.buffer) >= core_len + 2:
                if self.buffer[core_len:core_len + 2] == b"\r\n":
                    total_consume += 2

            frame = HBFrame.decode(candidate)
            if frame is not None:
                del self.buffer[:total_consume]
                frames.append(frame)
            else:
                # Preserve valid frames hidden behind a corrupt length/checksum.
                del self.buffer[0]

        return frames
