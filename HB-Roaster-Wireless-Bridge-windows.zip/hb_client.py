"""
HB Roaster Wi-Fi Client
Handles UDP device discovery, TCP communication, 1 Hz temperature polling,
automatic reconnection, and actuation controls.
"""

from __future__ import annotations
import os
import sys
import struct
import socket
import select
import threading
import time
import logging
from typing import Optional, Callable, Tuple, List

from hb_protocol import HBFrame, HBDataType, HBStreamDecoder

logger = logging.getLogger("hb_client")


class HBDiscovery:
    UDP_PORT = 17888
    DISCOVERY_MSG = b"whereareyou\r\n"
    LAST_IP_FILE = os.path.expanduser("~/.hb_roaster_last_ip")

    @classmethod
    def get_last_known_ip(cls) -> Optional[str]:
        if os.path.exists(cls.LAST_IP_FILE):
            try:
                with open(cls.LAST_IP_FILE, "r") as f:
                    ip = f.read().strip()
                    if ip:
                        return ip
            except Exception:
                pass
        return None

    @classmethod
    def save_last_known_ip(cls, ip: str):
        try:
            with open(cls.LAST_IP_FILE, "w") as f:
                f.write(ip.strip())
        except Exception:
            pass

    @classmethod
    def get_local_broadcast_addrs(cls) -> List[str]:
        """Detects local IPv4 broadcast addresses on Windows, macOS, and Linux."""
        addrs = ["255.255.255.255"]
        try:
            if sys.platform == "win32":
                # Windows: parse ipconfig output with encoding resilience
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                res = subprocess.run(["ipconfig"], capture_output=True, creationflags=creationflags)
                try:
                    stdout_str = res.stdout.decode("utf-8", "ignore")
                except Exception:
                    stdout_str = res.stdout.decode("gbk", "ignore")

                import re
                current_ip = None
                for line in stdout_str.splitlines():
                    ip_match = re.search(r"IPv4 Address[ .]*:\s*([\d.]+)", line)
                    if ip_match:
                        current_ip = ip_match.group(1).strip()
                    mask_match = re.search(r"Subnet Mask[ .]*:\s*([\d.]+)", line)
                    if mask_match and current_ip:
                        mask = mask_match.group(1).strip()
                        try:
                            ip_parts = [int(p) for p in current_ip.split(".")]
                            mask_parts = [int(p) for p in mask.split(".")]
                            bcast = ".".join(str(ip_parts[i] | (~mask_parts[i] & 0xFF)) for i in range(4))
                            if bcast not in addrs and not bcast.startswith("127."):
                                addrs.append(bcast)
                        except Exception:
                            pass
                        current_ip = None

                # Also check local hostname IPs
                try:
                    _, _, ip_list = socket.gethostbyname_ex(socket.gethostname())
                    for host_ip in ip_list:
                        if not host_ip.startswith("127."):
                            parts = host_ip.split(".")
                            if len(parts) == 4:
                                bcast = f"{parts[0]}.{parts[1]}.{parts[2]}.255"
                                if bcast not in addrs:
                                    addrs.append(bcast)
                except Exception:
                    pass

                # Common default HB subnets
                for fallback in ["192.168.88.255", "192.168.4.255", "192.168.1.255"]:
                    if fallback not in addrs:
                        addrs.append(fallback)
            else:
                # macOS / Linux: check ifconfig
                res = subprocess.run(["ifconfig"], capture_output=True, text=True)
                for line in res.stdout.splitlines():
                    if "broadcast" in line:
                        parts = line.strip().split()
                        for idx, part in enumerate(parts):
                            if part == "broadcast" and idx + 1 < len(parts):
                                b_ip = parts[idx + 1]
                                if b_ip not in addrs and not b_ip.startswith("127."):
                                    addrs.append(b_ip)
        except Exception:
            pass
        return addrs

    @classmethod
    def discover(cls, timeout: float = 3.0) -> Optional[Tuple[str, str]]:
        """
        Broadcasts UDP discovery message to find the HB roaster on local subnets.
        Bypasses macOS VPN / TUN routing by using IP_BOUND_IF on Wi-Fi (en0) and targeting
        subnet broadcast addresses directly.
        """
        # First check last known IP if available
        last_ip = cls.get_last_known_ip()
        targets = set(cls.get_local_broadcast_addrs())
        targets.add("255.255.255.255")
        targets.add("192.168.4.1") # Roaster AP mode fallback
        if last_ip:
            targets.add(last_ip)

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # On macOS, bind to physical en0 interface if present to avoid VPN (Loon/Clash) capture
        if sys.platform == "darwin":
            try:
                if_idx = socket.if_nametoindex("en0")
                IP_BOUND_IF = 25
                sock.setsockopt(socket.IPPROTO_IP, IP_BOUND_IF, struct.pack("I", if_idx))
            except Exception:
                pass

        sock.settimeout(timeout)

        try:
            for tgt in targets:
                try:
                    sock.sendto(cls.DISCOVERY_MSG, (tgt, cls.UDP_PORT))
                except Exception:
                    pass

            start_time = time.time()
            while time.time() - start_time < timeout:
                try:
                    data, (addr, _) = sock.recvfrom(512)
                    dev_id = data.decode("utf-8", "ignore").strip()
                    logger.info("Discovered HB Roaster at %s (ID: %s)", addr, dev_id)
                    cls.save_last_known_ip(addr)
                    return addr, dev_id
                except socket.timeout:
                    break
        except Exception as e:
            logger.warning("UDP discovery error: %s", e)
        finally:
            sock.close()

        return None


class HBClient:
    TCP_PORT = 16888

    def __init__(
        self,
        host: Optional[str] = None,
        port: int = TCP_PORT,
        auto_reconnect: bool = True,
        poll_interval: float = 1.0,
    ):
        self.host = host
        self.port = port
        self.auto_reconnect = auto_reconnect
        self.poll_interval = poll_interval

        # Callbacks
        self.on_temperatures: Optional[Callable[[float, float, float, float], None]] = None
        self.on_connection_state: Optional[Callable[[bool, str], None]] = None

        # State
        self.is_connected = False
        self.exhaust: float = 0.0
        self.inlet: float = 0.0
        self.bt: float = 0.0
        self.et: float = 0.0
        self.last_temp_time: float = 0.0
        self._connected_at: float = 0.0

        self.power_on: Optional[bool] = None
        self.heat_on: Optional[bool] = None
        self.stir_on: Optional[bool] = None
        self.fan_on: Optional[bool] = None
        self.timer_running: Optional[bool] = None

        self._seq = 0
        self._sock: Optional[socket.socket] = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._control_lock = threading.Lock()
        self._pending_controls = {}
        self._decoder = HBStreamDecoder()

    def start(self):
        """Starts the background worker thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, name="HBClientThread", daemon=True)
        self._thread.start()

    def stop(self):
        """Stops the client and closes sockets."""
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
        self._disconnect()

    def _next_seq(self) -> int:
        self._seq = (self._seq + 1) & 0xFF
        return self._seq

    def send_frame(self, frame: HBFrame, preserve_sequence: bool = False) -> bool:
        """Never disconnect while holding the non-reentrant socket lock."""
        error = None
        failed_socket = None
        with self._lock:
            if not self._sock or not self.is_connected:
                return False
            if not frame.is_response and not preserve_sequence:
                frame.sequence = self._next_seq()
            raw = frame.encode(append_crlf=True)
            try:
                self._sock.sendall(raw)
            except Exception as exc:
                error = exc
                failed_socket = self._sock
        if error is not None:
            logger.error("Failed to send frame: %s", error)
            self._disconnect(expected_socket=failed_socket)
            return False
        return True

    def temperature_snapshot(self):
        with self._lock:
            if not self.is_connected or self.last_temp_time <= 0 or time.time() - self.last_temp_time > 3:
                return None
            return self.exhaust, self.inlet, self.bt, self.et

    def _set_control(self, frame: HBFrame):
        with self._control_lock:
            if not self.send_frame(frame):
                raise ConnectionError("烘焙机未连接或发送失败")
            request = HBFrame.read(frame.data_type)
            event = threading.Event()
            result = []
            with self._lock:
                request.sequence = self._next_seq()
                self._pending_controls[request.sequence] = (event, frame.data_type, frame.payload, result)
            try:
                if not self.send_frame(request, preserve_sequence=True):
                    raise ConnectionError("状态查询发送失败")
                if not event.wait(timeout=3):
                    raise TimeoutError("设备状态确认超时，请检查机器实际状态")
                if not result or not result[0]:
                    raise RuntimeError("设备实际状态与指令不一致，或连接已断开")
            except Exception:
                with self._lock:
                    if frame.data_type == HBDataType.POWER_STATE:
                        self.power_on = None
                    elif frame.data_type == HBDataType.HEAT_STATE:
                        self.heat_on = None
                    elif frame.data_type == HBDataType.COOLING_STATE:
                        self.stir_on = self.fan_on = None
                    elif frame.data_type == HBDataType.TIMER_STATE:
                        self.timer_running = None
                self.send_frame(HBFrame.read(frame.data_type))
                raise
            finally:
                with self._lock:
                    self._pending_controls.pop(request.sequence, None)

    def set_power(self, on: bool):
        self._set_control(HBFrame.set_power(on))

    def set_heat(self, on: bool):
        self._set_control(HBFrame.set_heat(on))

    def set_cooling(self, stir: bool, fan: bool):
        self._set_control(HBFrame.set_cooling(stir, fan))

    def set_timer(self, running: bool):
        self._set_control(HBFrame.set_timer(running))

    def _disconnect(self, expected_socket=None):
        with self._lock:
            if expected_socket is not None and self._sock is not expected_socket:
                return
            if self._sock:
                try:
                    self._sock.close()
                except Exception:
                    pass
                self._sock = None
            was_connected = self.is_connected
            self.is_connected = False
            self.last_temp_time = 0
            self._connected_at = 0
            self.power_on = self.heat_on = self.stir_on = self.fan_on = self.timer_running = None
            for event, _, _, result in self._pending_controls.values():
                result.append(False)
                event.set()
            self._pending_controls.clear()
            self._decoder = HBStreamDecoder()

        if was_connected and self.on_connection_state:
            self.on_connection_state(False, "Disconnected")

    def _connect(self) -> bool:
        # If no host specified, attempt UDP auto-discovery
        target_host = self.host
        if not target_host:
            logger.info("Scanning for HB roaster via UDP broadcast...")
            res = HBDiscovery.discover(timeout=2.5)
            if res:
                target_host = res[0]
                self.host = target_host
            else:
                logger.debug("Discovery timed out; will retry.")
                return False

        logger.info("Connecting to HB Roaster at %s:%d...", target_host, self.port)
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(4.0)
            # TCP keepalive
            s.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            s.connect((target_host, self.port))
            s.setblocking(False)

            with self._lock:
                self._sock = s
                self.is_connected = True
                self.last_temp_time = 0  # A TCP connection is not a fresh temperature sample.
                self._connected_at = time.time()

            logger.info("Successfully connected to HB Roaster at %s:%d", target_host, self.port)
            if self.on_connection_state:
                self.on_connection_state(True, f"Connected to {target_host}:{self.port}")

            # Query initial control states
            self._query_initial_states()
            return True
        except Exception as e:
            logger.warning("Connection to %s:%d failed: %s", target_host, self.port, e)
            self._disconnect()
            return False

    def _query_initial_states(self):
        for dtype in [HBDataType.POWER_STATE, HBDataType.HEAT_STATE, HBDataType.COOLING_STATE, HBDataType.TIMER_STATE]:
            self.send_frame(HBFrame.read(dtype))
            time.sleep(0.05)

    def _handle_frame(self, frame: HBFrame):
        # Acknowledge commands from roaster if high bit is clear
        if not frame.is_response:
            self.send_frame(frame.command_response())

        if frame.data_type == HBDataType.TEMPERATURES:
            temps = frame.temperatures()
            if temps:
                with self._lock:
                    self.exhaust, self.inlet, self.bt, self.et = temps
                    self.last_temp_time = time.time()
                if self.on_temperatures:
                    self.on_temperatures(self.exhaust, self.inlet, self.bt, self.et)

        elif frame.is_response and frame.control != 0x80:
            return  # A write ACK is not a readback of actual state.
        elif frame.data_type == HBDataType.POWER_STATE:
            if frame.payload:
                self.power_on = (frame.payload[0] != 0)
        elif frame.data_type == HBDataType.HEAT_STATE:
            if frame.payload:
                self.heat_on = (frame.payload[0] != 0)
        elif frame.data_type == HBDataType.COOLING_STATE:
            if frame.payload:
                b = frame.payload[0]
                self.stir_on = bool(b & 0x02)
                self.fan_on = bool(b & 0x01)
        elif frame.data_type == HBDataType.TIMER_STATE:
            if frame.payload:
                self.timer_running = (frame.payload[0] == 0)

        with self._lock:
            pending = self._pending_controls.get(frame.sequence)
            if frame.control == 0x80 and pending and frame.data_type == pending[1]:
                event, _, expected, result = pending
                if frame.data_type in (HBDataType.POWER_STATE, HBDataType.HEAT_STATE):
                    matches = bool(frame.payload) and bool(expected) and (frame.payload[0] != 0) == (expected[0] != 0)
                else:
                    matches = frame.payload == expected
                result.append(matches)
                event.set()

    def _run_loop(self):
        last_poll_time = 0.0

        while self._running:
            if not self.is_connected:
                success = self._connect()
                if not success:
                    time.sleep(2.0)
                    continue

            # Poll for temperatures
            now = time.time()
            if now - last_poll_time >= self.poll_interval:
                last_poll_time = now
                self.send_frame(HBFrame.read(HBDataType.TEMPERATURES))

            # Stale data watchdog (if no temp response in 6 seconds, reconnect)
            last_response = self.last_temp_time or self._connected_at
            if last_response > 0 and (now - last_response > 6.0):
                logger.warning("No temperature response from roaster for >6s; resetting connection.")
                self._disconnect()
                time.sleep(1.0)
                continue

            # Read socket data
            s = self._sock
            if not s:
                continue

            try:
                r, _, _ = select.select([s], [], [], 0.1)
                if r:
                    data = s.recv(2048)
                    if not data:
                        logger.warning("Roaster closed TCP connection.")
                        self._disconnect()
                        time.sleep(1.0)
                        continue
                    frames = self._decoder.append(data)
                    for frame in frames:
                        self._handle_frame(frame)
            except Exception as e:
                logger.warning("Socket read error: %s", e)
                self._disconnect()
                time.sleep(1.0)
