"""
Lightweight Web Dashboard and API Server for HB Roaster & Artisan Bridge.
Implemented using only Python standard library (http.server, threading, json).
Provides a modern web UI, REST API, and Server-Sent Events (SSE) live data stream.
"""

from __future__ import annotations
import json
import logging
import time
import threading
import secrets
import hmac
from http import HTTPStatus
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hb_client import HBClient
    from artisan_tc4_bridge import ArtisanTC4Bridge

logger = logging.getLogger("web_server")

HTML_DASHBOARD = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HB Roaster Wireless Bridge - 无线 Artisan 桥接</title>
<style>
  :root {
    --bg: #151618;
    --card: #1e2023;
    --card-border: #2c2f35;
    --text: #e8ebee;
    --text-muted: #888e99;
    --accent: #b37b5c;
    --bt: #4f8c70;
    --et: #b36359;
    --ex: #61809e;
    --in: #ad8c5c;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
  body { background: var(--bg); color: var(--text); padding: 24px 16px; min-height: 100vh; }
  .container { max-width: 900px; margin: 0 auto; }
  header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--card-border); }
  h1 { font-size: 20px; font-weight: 700; letter-spacing: -0.3px; }
  .badge { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 999px; font-size: 13px; font-weight: 500; }
  .badge-online { background: rgba(79, 140, 112, 0.15); color: #4f8c70; }
  .badge-offline { background: rgba(179, 99, 89, 0.15); color: #b36359; }
  .dot { width: 8px; height: 8px; border-radius: 50%; background: currentColor; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
  .card { background: var(--card); border: 1px solid var(--card-border); border-radius: 14px; padding: 18px; }
  .card-label { font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; display: flex; justify-content: space-between; }
  .card-value { font-size: 38px; font-weight: 700; line-height: 1.1; font-variant-numeric: tabular-nums; }
  .card-unit { font-size: 18px; font-weight: 400; color: var(--text-muted); margin-left: 4px; }
  .color-bt { color: var(--bt); }
  .color-et { color: var(--et); }
  .color-ex { color: var(--ex); }
  .color-in { color: var(--in); }
  .panel { background: var(--card); border: 1px solid var(--card-border); border-radius: 14px; padding: 20px; margin-bottom: 24px; }
  .panel-title { font-size: 15px; font-weight: 600; margin-bottom: 14px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
  .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 14px; }
  .info-row:last-child { border-bottom: none; }
  .info-key { color: var(--text-muted); }
  .info-val { font-weight: 600; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
  .btn-group { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 14px; }
  .lang-switch { display: inline-flex; border: 1px solid var(--card-border); border-radius: 8px; overflow: hidden; }
  .lang-btn { background: var(--card); border: none; border-radius: 0; padding: 4px 10px; font-size: 12px; font-weight: 600; cursor: pointer; color: var(--text-muted); }
  .lang-btn.active { background: var(--accent); color: #fff; }
  button {
    background: #2b2e38; color: var(--text); border: 1px solid var(--card-border);
    padding: 10px 18px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer;
    transition: all 0.15s ease;
  }
  button:hover { background: #393d4a; }
  button.active { background: var(--accent); color: #fff; border-color: var(--accent); }
  .footer { text-align: center; font-size: 13px; color: var(--text-muted); margin-top: 30px; }
</style>
</head>
<body>
<div class="container">
  <header>
    <div>
      <h1 id="appTitle">HB Roaster Wireless Bridge &middot; Artisan 桥</h1>
      <p id="appSubtitle" style="font-size: 13px; color: var(--text-muted); margin-top: 4px;">Arduino TC4 虚拟串口已就绪</p>
    </div>
    <div style="display: flex; align-items: center; gap: 12px;">
      <div id="statusBadge" class="badge badge-offline">
        <span class="dot"></span>
        <span id="statusText">连接中...</span>
      </div>
      <div class="lang-switch">
        <button id="btnLangZh" class="lang-btn" onclick="setLang('zh')">中文</button>
        <button id="btnLangEn" class="lang-btn" onclick="setLang('en')">EN</button>
      </div>
    </div>
  </header>

  <div class="grid">
    <div class="card">
      <div class="card-label color-bt" id="labelBT">豆温 (BT)</div>
      <div class="card-value color-bt"><span id="btVal">--.-</span><span class="card-unit">&deg;C</span></div>
    </div>
    <div class="card">
      <div class="card-label color-et" id="labelET">环境 (ET)</div>
      <div class="card-value color-et"><span id="etVal">--.-</span><span class="card-unit">&deg;C</span></div>
    </div>
    <div class="card">
      <div class="card-label color-ex" id="labelEX">出风 (Exhaust)</div>
      <div class="card-value color-ex"><span id="exVal">--.-</span><span class="card-unit">&deg;C</span></div>
    </div>
    <div class="card">
      <div class="card-label color-in" id="labelIN">进风 (Inlet)</div>
      <div class="card-value color-in"><span id="inVal">--.-</span><span class="card-unit">&deg;C</span></div>
    </div>
  </div>

  <div class="panel">
    <div class="panel-title" id="titleComms">通信与串口状态</div>
    <div class="info-row">
      <span class="info-key" id="keyRoasterAddr">烘焙机 Wi-Fi 地址</span>
      <span class="info-val" id="roasterAddr">--</span>
    </div>
    <div class="info-row">
      <span class="info-key" id="keySerialPath">Artisan 串口路径</span>
      <span class="info-val" id="serialPortPath">/tmp/hb_roaster</span>
    </div>
    <div class="info-row">
      <span class="info-key" id="keyArtisanStatus">Artisan 轮询状态</span>
      <span class="info-val" id="artisanStatus">等待 Artisan 连接...</span>
    </div>
    <div class="info-row">
      <span class="info-key" id="keyLastTime">最近更新时间</span>
      <span class="info-val" id="lastTime">--</span>
    </div>
  </div>

  <div class="panel">
    <div class="panel-title" id="titleControls">硬件控制 (可选)</div>
    <div class="btn-group">
      <button id="btnPower" onclick="toggleCtrl('power')">整机电源</button>
      <button id="btnHeat" onclick="toggleCtrl('heat')">电热加热</button>
      <button id="btnFan" onclick="toggleCtrl('fan')">降温风扇</button>
      <button id="btnStir" onclick="toggleCtrl('stir')">搅拌降温</button>
      <button id="btnTimer" onclick="toggleCtrl('timer')">计时器</button>
    </div>
  </div>

  <div class="footer">
    HB Roaster Wireless Bridge &bull; Artisan Roaster Scope Compatible
  </div>
</div>

<script>
let lastState = {};
const i18n = {
  zh: {
    title: "HB Roaster Wireless Bridge &middot; Artisan 桥",
    subtitle: "Arduino TC4 虚拟串口已就绪",
    online: "已连接烘焙机",
    offline: "烘焙机未连接",
    scanning: "自动扫描中...",
    bt: "豆温 (BT)",
    et: "环境 (ET)",
    ex: "出风 (Exhaust)",
    in: "进风 (Inlet)",
    comms: "通信与串口状态",
    roasterAddr: "烘焙机 Wi-Fi 地址",
    serialPath: "Artisan 串口路径",
    artisanStatus: "Artisan 轮询状态",
    lastTime: "最近更新时间",
    artisanActive: "Artisan 采集中 (活跃)",
    artisanIdle: "等待 Artisan 连接...",
    controls: "硬件控制 (可选)",
    power: "整机电源",
    heat: "电热加热",
    fan: "降温风扇",
    stir: "搅拌降温",
    timer: "计时器",
    confirmPower: "⚠️ 确定要关闭整机电源吗？\\n烘焙过程中关闭电源将导致滚筒停止转动，可能造成咖啡豆焦糊。",
    confirmHeat: "🔥 确定要关闭电热加热吗？\\n关闭后将停止向烘焙锅炉供热。",
    controlErr: "控制未确认，请检查机器实际状态。\\n"
  },
  en: {
    title: "HB Roaster Wireless Bridge &middot; Artisan Bridge",
    subtitle: "Arduino TC4 Virtual Serial Port Ready",
    online: "Roaster Connected",
    offline: "Roaster Disconnected",
    scanning: "Auto-scanning...",
    bt: "Bean Temp (BT)",
    et: "Env Temp (ET)",
    ex: "Exhaust (MET)",
    in: "Inlet (IT)",
    comms: "Communication & Port Status",
    roasterAddr: "Roaster Wi-Fi Address",
    serialPath: "Artisan Serial Port",
    artisanStatus: "Artisan Polling Status",
    lastTime: "Last Update Time",
    artisanActive: "Artisan Sampling (Active)",
    artisanIdle: "Waiting for Artisan...",
    controls: "Roaster Controls (Optional)",
    power: "Power",
    heat: "Heat",
    fan: "Fan",
    stir: "Agitation",
    timer: "Timer",
    confirmPower: "⚠️ Turn off roaster power?\\nDrum will stop rotating; beans may scorch if hot.",
    confirmHeat: "🔥 Turn off heating element?\\nHeat supply to roaster will stop.",
    controlErr: "Control unconfirmed, please check roaster status.\\n"
  }
};

let currentLang = localStorage.getItem("hb_lang") || (navigator.language && navigator.language.startsWith("zh") ? "zh" : "en");

function setLang(lang) {
  currentLang = lang;
  localStorage.setItem("hb_lang", lang);
  applyLang();
  updateUI(lastState);
}

function applyLang() {
  const t = i18n[currentLang];
  document.getElementById("btnLangZh").classList.toggle("active", currentLang === "zh");
  document.getElementById("btnLangEn").classList.toggle("active", currentLang === "en");
  document.getElementById("appTitle").innerHTML = t.title;
  document.getElementById("appSubtitle").textContent = t.subtitle;
  document.getElementById("labelBT").textContent = t.bt;
  document.getElementById("labelET").textContent = t.et;
  document.getElementById("labelEX").textContent = t.ex;
  document.getElementById("labelIN").textContent = t.in;
  document.getElementById("titleComms").textContent = t.comms;
  document.getElementById("keyRoasterAddr").textContent = t.roasterAddr;
  document.getElementById("keySerialPath").textContent = t.serialPath;
  document.getElementById("keyArtisanStatus").textContent = t.artisanStatus;
  document.getElementById("keyLastTime").textContent = t.lastTime;
  document.getElementById("titleControls").textContent = t.controls;
  document.getElementById("btnPower").textContent = t.power;
  document.getElementById("btnHeat").textContent = t.heat;
  document.getElementById("btnFan").textContent = t.fan;
  document.getElementById("btnStir").textContent = t.stir;
  document.getElementById("btnTimer").textContent = t.timer;
}

function updateUI(s) {
  lastState = s;
  const t = i18n[currentLang];
  const isOnline = s.roaster_connected;
  const badge = document.getElementById("statusBadge");
  const txt = document.getElementById("statusText");

  if (isOnline) {
    badge.className = "badge badge-online";
    txt.textContent = t.online;
  } else {
    badge.className = "badge badge-offline";
    txt.textContent = t.offline;
  }

  document.getElementById("btVal").textContent = s.bt ? s.bt.toFixed(1) : "--.-";
  document.getElementById("etVal").textContent = s.et ? s.et.toFixed(1) : "--.-";
  document.getElementById("exVal").textContent = s.exhaust ? s.exhaust.toFixed(1) : "--.-";
  document.getElementById("inVal").textContent = s.inlet ? s.inlet.toFixed(1) : "--.-";

  document.getElementById("roasterAddr").textContent = s.roaster_host ? (s.roaster_host + ":" + s.roaster_port) : t.scanning;
  document.getElementById("serialPortPath").textContent = s.serial_path || "/tmp/hb_roaster";

  const aStat = document.getElementById("artisanStatus");
  if (s.artisan_connected) {
    aStat.textContent = t.artisanActive;
    aStat.style.color = "#00d084";
  } else {
    aStat.textContent = t.artisanIdle;
    aStat.style.color = "#8c93a3";
  }

  if (s.last_temp_time > 0) {
    const d = new Date(s.last_temp_time * 1000);
    document.getElementById("lastTime").textContent = d.toLocaleTimeString();
  }

  // Update control button highlights
  setBtnState("btnPower", s.power_on);
  setBtnState("btnHeat", s.heat_on);
  setBtnState("btnFan", s.fan_on);
  setBtnState("btnStir", s.stir_on);
  setBtnState("btnTimer", s.timer_running);
}

function setBtnState(id, on) {
  const el = document.getElementById(id);
  if (!el) return;
  el.disabled = !lastState.roaster_connected || on == null;
  if (on) el.classList.add("active");
  else el.classList.remove("active");
}

function toggleCtrl(name) {
  const t = i18n[currentLang];
  const current = !!lastState[name + "_on"] || (name === "timer" && !!lastState.timer_running);
  if (current) {
    if (name === "power") {
      if (!confirm(t.confirmPower)) {
        return;
      }
    } else if (name === "heat") {
      if (!confirm(t.confirmHeat)) {
        return;
      }
    }
  }
  fetch("/api/control", {
    method: "POST",
    headers: {"Content-Type": "application/json", "X-HB-Token": "__HB_CONTROL_TOKEN__"},
    body: JSON.stringify({action: name, value: !current})
  }).then(async response => {
    if (!response.ok) throw new Error(await response.text());
  }).catch(e => alert(t.controlErr + e.message));
}

applyLang();

// Connect to Server-Sent Events (SSE)
function setupSSE() {
  const evtSource = new EventSource("/api/stream");
  evtSource.onmessage = function(e) {
    try {
      const data = JSON.parse(e.data);
      updateUI(data);
    } catch(err) {
      console.error(err);
    }
  };
  evtSource.onerror = function() {
    setTimeout(setupSSE, 2000);
  };
}
setupSSE();
</script>
</body>
</html>
"""


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


def make_request_handler(hb_client: HBClient, tc4_bridge: ArtisanTC4Bridge):
    control_token = secrets.token_urlsafe(32)

    class BridgeHandler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            # Suppress noisy HTTP access logs
            return

        def _get_status_dict(self):
            return {
                "roaster_connected": hb_client.is_connected,
                "roaster_host": hb_client.host,
                "roaster_port": hb_client.port,
                "artisan_connected": tc4_bridge.artisan_connected,
                "serial_path": tc4_bridge.symlink_path,
                "bt": hb_client.bt,
                "et": hb_client.et,
                "exhaust": hb_client.exhaust,
                "inlet": hb_client.inlet,
                "ambient": tc4_bridge.ambient_temp,
                "last_temp_time": hb_client.last_temp_time,
                "power_on": hb_client.power_on,
                "heat_on": hb_client.heat_on,
                "stir_on": hb_client.stir_on,
                "fan_on": hb_client.fan_on,
                "timer_running": hb_client.timer_running,
            }

        def _valid_host(self):
            port = self.server.server_address[1]
            host = self.headers.get("Host", "").lower()
            allowed = {f"127.0.0.1:{port}", f"localhost:{port}"}
            if port == 80:
                allowed.update({"127.0.0.1", "localhost"})
            return host in allowed

        def do_GET(self):
            if not self._valid_host():
                self.send_error(HTTPStatus.FORBIDDEN, "Invalid Host")
                return
            if self.path == "/" or self.path == "/index.html":
                content = HTML_DASHBOARD.replace("__HB_CONTROL_TOKEN__", control_token).encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)

            elif self.path == "/api/status":
                data = self._get_status_dict()
                body = json.dumps(data).encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            elif self.path == "/api/stream":
                # Server-Sent Events (SSE)
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "keep-alive")
                self.end_headers()

                try:
                    while getattr(self.server, "is_running", True):
                        data = self._get_status_dict()
                        payload = f"data: {json.dumps(data)}\n\n".encode("utf-8")
                        self.wfile.write(payload)
                        self.wfile.flush()
                        time.sleep(1.0)
                except (BrokenPipeError, ConnectionResetError, OSError):
                    pass

            else:
                self.send_error(HTTPStatus.NOT_FOUND, "Not Found")

        def do_POST(self):
            token = self.headers.get("X-HB-Token", "")
            origin = self.headers.get("Origin")
            if (not self._valid_host() or not hmac.compare_digest(token.encode(), control_token.encode())
                    or (origin is not None and origin != "http://" + self.headers.get("Host", ""))):
                self.send_error(HTTPStatus.FORBIDDEN, "Unauthorized control request")
                return
            if self.path == "/api/control":
                try:
                    content_len = int(self.headers.get("Content-Length", 0))
                    if not 0 < content_len <= 1024:
                        raise ValueError("Invalid request size")
                    payload = json.loads(self.rfile.read(content_len))
                    action = payload.get("action")
                    val = payload.get("value")
                    if type(val) is not bool or action not in {"power", "heat", "stir", "fan", "timer"}:
                        raise ValueError("Invalid control action or value")

                    if action == "power":
                        hb_client.set_power(val)
                    elif action == "heat":
                        hb_client.set_heat(val)
                    elif action == "stir":
                        if hb_client.fan_on is None:
                            raise RuntimeError("风扇状态尚未确认")
                        hb_client.set_cooling(stir=val, fan=hb_client.fan_on)
                    elif action == "fan":
                        if hb_client.stir_on is None:
                            raise RuntimeError("搅拌状态尚未确认")
                        hb_client.set_cooling(stir=hb_client.stir_on, fan=val)
                    elif action == "timer":
                        hb_client.set_timer(val)

                    self.send_response(HTTPStatus.OK)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(b'{"status":"ok"}')
                except (ConnectionError, TimeoutError, RuntimeError) as e:
                    self.send_error(HTTPStatus.SERVICE_UNAVAILABLE, str(e))
                except Exception as e:
                    self.send_error(HTTPStatus.BAD_REQUEST, str(e))
            else:
                self.send_error(HTTPStatus.NOT_FOUND, "Not Found")

    return BridgeHandler


class WebServer:
    def __init__(self, hb_client: HBClient, tc4_bridge: ArtisanTC4Bridge, port: int = 8080):
        self.hb_client = hb_client
        self.tc4_bridge = tc4_bridge
        self.port = port
        self.httpd: Optional[ThreadedHTTPServer] = None
        self._server_thread: Optional[threading.Thread] = None

    def start(self):
        handler_cls = make_request_handler(self.hb_client, self.tc4_bridge)
        try:
            self.httpd = ThreadedHTTPServer(("127.0.0.1", self.port), handler_cls)
            self.httpd.is_running = True
            logger.info("Web dashboard started on http://localhost:%d", self.port)
            self._server_thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
            self._server_thread.start()
        except Exception as e:
            if self.httpd:
                self.httpd.server_close()
                self.httpd = None
            logger.warning("Failed to start web dashboard on port %d: %s", self.port, e)

    def stop(self):
        if self.httpd:
            self.httpd.is_running = False
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
