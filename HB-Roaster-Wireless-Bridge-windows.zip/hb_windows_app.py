"""
HB Roaster & Artisan Wireless Bridge - Windows Desktop Application
Native Windows GUI with live 4-channel temperature dials, roaster control panel,
Artisan WebSocket / COM bridge status, and system tray integration.
"""

from __future__ import annotations
import os
import sys
import time
import socket
import threading
import logging
import webbrowser
from typing import Optional

# GUI library
try:
    import tkinter as tk
    from tkinter import ttk, messagebox
except ImportError:
    tk = None
    ttk = None
    messagebox = None

from hb_client import HBClient, HBDiscovery
from artisan_tc4_bridge import ArtisanTC4Bridge
from web_server import WebServer
import diagnose

logger = logging.getLogger("windows_app")

# Color palette (Modern dark theme matching macOS and Web UI)
THEME = {
    "bg": "#151618",
    "card": "#1e2023",
    "card_border": "#2c2f35",
    "text": "#e8ebee",
    "text_muted": "#888e99",
    "accent": "#b37b5c",
    "accent_hover": "#c98f6e",
    "bt": "#4f8c70",
    "et": "#b36359",
    "ex": "#61809e",
    "in": "#ad8c5c",
    "green": "#4f8c70",
    "red": "#b36359",
    "gray": "#555b66",
    "active_btn": "#3d7a5a",
}

STRINGS = {
    "zh": {
        "title": "HB Roaster 无线桥接中间件 (Windows 版)",
        "subtitle": "Artisan 烘焙无线桥接 · 零驱动 WebSocket / 虚拟串口",
        "roaster_online": "已连接",
        "roaster_offline": "未连接 (自动重试中)",
        "artisan_active": "Artisan 采集中 (活跃)",
        "artisan_waiting": "等待 Artisan 连接",
        "bt": "豆温 (BT)",
        "et": "炉温 (ET)",
        "ex": "出风温 (MET)",
        "in": "进风温 (IT)",
        "power": "机械总电",
        "heat": "加热电源",
        "stir": "冷却搅拌",
        "fan": "冷却排风",
        "confirm_heat_title": "⚠️ 加热电源操作确认",
        "confirm_heat_on": "确定要开启烘焙机加热管吗？请确保风机已运转并注意高温安全！",
        "confirm_heat_off": "确定要关闭烘焙机加热管吗？",
        "tab_artisan": "Artisan 连接设置",
        "tab_network": "烘焙机网络",
        "tab_system": "系统与诊断",
        "ws_title": "模式 1：WebSocket 极速直连 (推荐 · 零驱动免安装)",
        "ws_desc": "Artisan 原生支持 WebSocket，无需安装任何虚拟串口驱动：\n1. Artisan 菜单 -> 配置 (Config) -> 设备 (Device) -> 选 'WebSocket'\n2. Artisan 菜单 -> 配置 (Config) -> 端口 (Ports) -> WebSocket 标签页填入以下地址：",
        "copy_btn": "复制地址",
        "copied": "已复制到剪贴板！",
        "com_title": "模式 2：虚拟串口模式 (Arduino TC4 兼容)",
        "com_desc": "使用 com0com 等工具配对端口 (如 COM10 <-> COM11)。\nArtisan 设备选 'HB Model S'，端口填 COM10；本软件填 COM11：",
        "com_port_label": "串口名称:",
        "scan_roaster": "🔍 一键搜索烘焙机",
        "scanning": "正在全网段广播搜索...",
        "found_roaster": "已发现烘焙机: {ip}",
        "not_found": "未搜索到烘焙机，请确认已连接烘焙机 Wi-Fi 或处于同一局域网。",
        "roaster_ip_label": "烘焙机 IP 地址:",
        "roaster_port_label": "TCP 端口:",
        "reconnect_btn": "保存并立即重连",
        "autostart": "开机自动启动 (Start on Boot)",
        "min_to_tray": "关闭主窗口时最小化到系统托盘",
        "open_web": "在浏览器中打开网页控制台",
        "run_diag": "一键运行全面网络诊断",
        "diag_running": "正在诊断网络环境...",
        "tray_show": "显示主窗口",
        "tray_web": "打开网页控制台",
        "tray_exit": "完全退出",
    },
    "en": {
        "title": "HB Roaster Wireless Bridge (Windows)",
        "subtitle": "Artisan Roasting Scope Wireless Bridge",
        "roaster_online": "Connected",
        "roaster_offline": "Disconnected (Scanning...)",
        "artisan_active": "Artisan Active (Logging)",
        "artisan_waiting": "Waiting for Artisan",
        "bt": "Bean Temp (BT)",
        "et": "Env Temp (ET)",
        "ex": "Exhaust (MET)",
        "in": "Inlet (IT)",
        "power": "Main Power",
        "heat": "Heater Power",
        "stir": "Cooling Stir",
        "fan": "Cooling Fan",
        "confirm_heat_title": "⚠️ Heater Power Confirmation",
        "confirm_heat_on": "Are you sure you want to turn ON the heater? Ensure drum/fan are running!",
        "confirm_heat_off": "Are you sure you want to turn OFF the heater?",
        "tab_artisan": "Artisan Setup",
        "tab_network": "Roaster Network",
        "tab_system": "System & Diag",
        "ws_title": "Mode 1: Zero-Driver WebSocket (Recommended)",
        "ws_desc": "Artisan natively supports WebSocket without any virtual COM driver:\n1. Artisan -> Config -> Device -> Choose 'WebSocket'\n2. Artisan -> Config -> Ports -> WebSocket tab -> Input endpoint:",
        "copy_btn": "Copy URL",
        "copied": "Copied to clipboard!",
        "com_title": "Mode 2: Virtual COM Port (Arduino TC4 Emulation)",
        "com_desc": "Pair ports using com0com (e.g. COM10 <-> COM11).\nIn Artisan choose 'HB Model S' on COM10; enter COM11 here:",
        "com_port_label": "COM Port:",
        "scan_roaster": "🔍 Scan for Roaster",
        "scanning": "Broadcasting UDP discovery...",
        "found_roaster": "Discovered Roaster at {ip}",
        "not_found": "Roaster not found. Check Wi-Fi connection.",
        "roaster_ip_label": "Roaster IP:",
        "roaster_port_label": "TCP Port:",
        "reconnect_btn": "Save & Reconnect Now",
        "autostart": "Launch on Windows Startup",
        "min_to_tray": "Minimize to System Tray on close",
        "open_web": "Open Web Dashboard in Browser",
        "run_diag": "Run Full Network Diagnostics",
        "diag_running": "Diagnosing network...",
        "tray_show": "Show Window",
        "tray_web": "Open Web Dashboard",
        "tray_exit": "Exit",
    },
}


class WindowsAutoStart:
    """Manages Windows startup registry key."""
    REG_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
    APP_NAME = "HBRoasterWirelessBridge"

    @classmethod
    def is_enabled(cls) -> bool:
        if sys.platform != "win32":
            return False
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, cls.REG_PATH, 0, winreg.KEY_READ) as key:
                winreg.QueryValueEx(key, cls.APP_NAME)
                return True
        except Exception:
            return False

    @classmethod
    def set_enabled(cls, enable: bool) -> bool:
        if sys.platform != "win32":
            return False
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, cls.REG_PATH, 0, winreg.KEY_WRITE) as key:
                if enable:
                    exe_path = os.path.abspath(sys.argv[0])
                    # If running python script directly, launch pythonw
                    if exe_path.endswith(".py"):
                        exe_path = f'"{sys.executable}" "{exe_path}"'
                    else:
                        exe_path = f'"{exe_path}"'
                    winreg.SetValueEx(key, cls.APP_NAME, 0, winreg.REG_SZ, exe_path)
                else:
                    try:
                        winreg.DeleteValue(key, cls.APP_NAME)
                    except FileNotFoundError:
                        pass
            return True
        except Exception as e:
            logger.warning("Failed to modify Windows startup registry: %s", e)
            return False


class HBRoasterWindowsApp:
    def __init__(self, root: tk.Tk, args):
        self.root = root
        self.args = args
        self.lang = "zh"
        self.t = STRINGS[self.lang]

        # Windows taskbar grouping & title
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("koldllc.hbroaster.bridge.1.2")
            except Exception:
                pass

        self.root.title(self.t["title"])
        self.root.geometry("640x780")
        self.root.minsize(580, 680)
        self.root.configure(bg=THEME["bg"])

        # Set Window icon if present
        self._load_icon()

        # Core logic instances
        self.roaster_ip = args.ip or HBDiscovery.get_last_known_ip()
        self.client = HBClient(host=self.roaster_ip, port=args.port)

        com_port = args.pty if (args.pty and args.pty.upper().startswith("COM")) else "COM11"
        self.bridge = ArtisanTC4Bridge(
            hb_client=self.client,
            symlink_path=com_port,
            enable_websocket=not args.no_ws,
            ws_port=args.ws_port,
        )

        self.web = None if args.no_web else WebServer(self.client, self.bridge, port=args.web_port)

        # Start background bridge services
        self.client.start()
        self.bridge.start()
        if self.web:
            self.web.start()

        # State tracking for UI
        self.min_to_tray_var = tk.BooleanVar(value=True)
        self.autostart_var = tk.BooleanVar(value=WindowsAutoStart.is_enabled())

        # Build UI layout
        self._setup_styles()
        self._build_header()
        self._build_temp_cards()
        self._build_control_panel()
        self._build_tabs()
        self._build_footer()

        # System tray setup
        self.tray_icon = None
        self._setup_tray()

        # Window close handler
        self.root.protocol("WM_DELETE_WINDOW", self._on_close_window)

        # Start periodic UI refresh timer (100ms)
        self.root.after(100, self._periodic_update)

    def _load_icon(self):
        icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "AppIcon.ico")
        if os.path.exists(icon_path):
            try:
                self.root.iconbitmap(icon_path)
            except Exception:
                pass

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(".", background=THEME["bg"], foreground=THEME["text"])
        style.configure("TNotebook", background=THEME["bg"], borderwidth=0)
        style.configure("TNotebook.Tab", background=THEME["card"], foreground=THEME["text_muted"],
                        padding=[14, 6], font=("Segoe UI", 10, "bold"), borderwidth=0)
        style.map("TNotebook.Tab",
                  background=[("selected", THEME["accent"]), ("active", "#2c2f35")],
                  foreground=[("selected", "#ffffff"), ("active", THEME["text"])])

    def _build_header(self):
        header_frame = tk.Frame(self.root, bg=THEME["bg"], padx=18, pady=12)
        header_frame.pack(fill=tk.X)

        title_sub_frame = tk.Frame(header_frame, bg=THEME["bg"])
        title_sub_frame.pack(side=tk.LEFT)

        self.title_lbl = tk.Label(
            title_sub_frame,
            text="☕ " + self.t["title"],
            font=("Segoe UI", 14, "bold"),
            fg=THEME["text"],
            bg=THEME["bg"],
        )
        self.title_lbl.pack(anchor="w")

        self.subtitle_lbl = tk.Label(
            title_sub_frame,
            text=self.t["subtitle"],
            font=("Segoe UI", 9),
            fg=THEME["text_muted"],
            bg=THEME["bg"],
        )
        self.subtitle_lbl.pack(anchor="w")

        # Right side: Language switch button
        btn_frame = tk.Frame(header_frame, bg=THEME["bg"])
        btn_frame.pack(side=tk.RIGHT)

        self.lang_btn = tk.Button(
            btn_frame,
            text="EN" if self.lang == "zh" else "中文",
            font=("Segoe UI", 9, "bold"),
            bg=THEME["card"],
            fg=THEME["text"],
            activebackground=THEME["card_border"],
            activeforeground=THEME["text"],
            bd=1,
            relief="flat",
            padx=10,
            pady=4,
            cursor="hand2",
            command=self._toggle_language,
        )
        self.lang_btn.pack(side=tk.RIGHT)

        # Status pills bar
        status_bar = tk.Frame(self.root, bg=THEME["card"], padx=16, pady=8, highlightbackground=THEME["card_border"], highlightthickness=1)
        status_bar.pack(fill=tk.X, padx=16, pady=(0, 12))

        self.roaster_pill = tk.Label(
            status_bar,
            text="● " + self.t["roaster_offline"],
            font=("Segoe UI", 10, "bold"),
            fg=THEME["red"],
            bg=THEME["card"],
        )
        self.roaster_pill.pack(side=tk.LEFT)

        self.artisan_pill = tk.Label(
            status_bar,
            text="● " + self.t["artisan_waiting"],
            font=("Segoe UI", 10, "bold"),
            fg=THEME["gray"],
            bg=THEME["card"],
        )
        self.artisan_pill.pack(side=tk.RIGHT)

    def _build_temp_cards(self):
        grid_frame = tk.Frame(self.root, bg=THEME["bg"], padx=16)
        grid_frame.pack(fill=tk.X)

        self.cards = {}
        channels = [
            ("bt", self.t["bt"], THEME["bt"], 0, 0),
            ("et", self.t["et"], THEME["et"], 0, 1),
            ("ex", self.t["ex"], THEME["ex"], 1, 0),
            ("in", self.t["in"], THEME["in"], 1, 1),
        ]

        grid_frame.columnconfigure(0, weight=1)
        grid_frame.columnconfigure(1, weight=1)

        for key, name, color, row, col in channels:
            card = tk.Frame(grid_frame, bg=THEME["card"], padx=14, pady=12,
                            highlightbackground=THEME["card_border"], highlightthickness=1)
            card.grid(row=row, column=col, sticky="nsew", padx=6, pady=6)

            title_lbl = tk.Label(card, text=name, font=("Segoe UI", 10, "bold"),
                                 fg=THEME["text_muted"], bg=THEME["card"])
            title_lbl.pack(anchor="w")

            val_frame = tk.Frame(card, bg=THEME["card"])
            val_frame.pack(anchor="w", pady=(4, 0))

            val_lbl = tk.Label(val_frame, text="--.-", font=("Segoe UI", 28, "bold"),
                               fg=color, bg=THEME["card"])
            val_lbl.pack(side=tk.LEFT)

            unit_lbl = tk.Label(val_frame, text=" °C", font=("Segoe UI", 14),
                                fg=THEME["text_muted"], bg=THEME["card"])
            unit_lbl.pack(side=tk.LEFT, pady=(8, 0))

            self.cards[key] = {
                "title": title_lbl,
                "val": val_lbl,
            }

    def _build_control_panel(self):
        ctrl_frame = tk.Frame(self.root, bg=THEME["card"], padx=14, pady=12,
                              highlightbackground=THEME["card_border"], highlightthickness=1)
        ctrl_frame.pack(fill=tk.X, padx=16, pady=12)

        tk.Label(ctrl_frame, text="机身控制 (Roaster Actuators)", font=("Segoe UI", 10, "bold"),
                 fg=THEME["text_muted"], bg=THEME["card"]).pack(anchor="w", pady=(0, 8))

        btn_row = tk.Frame(ctrl_frame, bg=THEME["card"])
        btn_row.pack(fill=tk.X)

        self.btn_power = self._make_control_btn(btn_row, self.t["power"], self._cmd_power)
        self.btn_heat = self._make_control_btn(btn_row, self.t["heat"], self._cmd_heat)
        self.btn_stir = self._make_control_btn(btn_row, self.t["stir"], self._cmd_stir)
        self.btn_fan = self._make_control_btn(btn_row, self.t["fan"], self._cmd_fan)

        self.btn_power.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=4)
        self.btn_heat.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=4)
        self.btn_stir.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=4)
        self.btn_fan.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=4)

    def _make_control_btn(self, parent, text, cmd):
        btn = tk.Button(
            parent,
            text=text,
            font=("Segoe UI", 10, "bold"),
            bg="#2b2e38",
            fg=THEME["text"],
            activebackground=THEME["accent"],
            activeforeground="#ffffff",
            bd=1,
            relief="flat",
            pady=8,
            cursor="hand2",
            command=cmd,
        )
        return btn

    def _build_tabs(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=16, pady=(0, 10))

        # Tab 1: Artisan Setup
        self.tab_artisan = tk.Frame(self.notebook, bg=THEME["bg"], padx=14, pady=12)
        self.notebook.add(self.tab_artisan, text=self.t["tab_artisan"])
        self._build_tab_artisan_content()

        # Tab 2: Roaster Network
        self.tab_network = tk.Frame(self.notebook, bg=THEME["bg"], padx=14, pady=12)
        self.notebook.add(self.tab_network, text=self.t["tab_network"])
        self._build_tab_network_content()

        # Tab 3: System & Diagnostics
        self.tab_system = tk.Frame(self.notebook, bg=THEME["bg"], padx=14, pady=12)
        self.notebook.add(self.tab_system, text=self.t["tab_system"])
        self._build_tab_system_content()

    def _build_tab_artisan_content(self):
        # Mode 1: WebSocket
        ws_card = tk.Frame(self.tab_artisan, bg=THEME["card"], padx=12, pady=10,
                           highlightbackground=THEME["card_border"], highlightthickness=1)
        ws_card.pack(fill=tk.X, pady=(0, 10))

        tk.Label(ws_card, text=self.t["ws_title"], font=("Segoe UI", 10, "bold"),
                 fg=THEME["green"], bg=THEME["card"]).pack(anchor="w")

        self.ws_desc_lbl = tk.Label(ws_card, text=self.t["ws_desc"], font=("Segoe UI", 9),
                                    fg=THEME["text_muted"], bg=THEME["card"], justify=tk.LEFT)
        self.ws_desc_lbl.pack(anchor="w", pady=(4, 6))

        ep_frame = tk.Frame(ws_card, bg=THEME["card"])
        ep_frame.pack(fill=tk.X, pady=4)

        ws_url = f"ws://127.0.0.1:{self.args.ws_port}/ws"
        self.ws_entry = tk.Entry(ep_frame, font=("Segoe UI", 10, "bold"), bg="#151618",
                                 fg=THEME["accent"], bd=1, relief="flat")
        self.ws_entry.insert(0, ws_url)
        self.ws_entry.config(state="readonly")
        self.ws_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8), ipady=3)

        copy_btn = tk.Button(ep_frame, text=self.t["copy_btn"], font=("Segoe UI", 9, "bold"),
                             bg=THEME["accent"], fg="#fff", activebackground=THEME["accent_hover"],
                             bd=0, relief="flat", padx=12, cursor="hand2", command=self._copy_ws_url)
        copy_btn.pack(side=tk.RIGHT)

        # Mode 2: Virtual COM
        com_card = tk.Frame(self.tab_artisan, bg=THEME["card"], padx=12, pady=10,
                            highlightbackground=THEME["card_border"], highlightthickness=1)
        com_card.pack(fill=tk.X)

        tk.Label(com_card, text=self.t["com_title"], font=("Segoe UI", 10, "bold"),
                 fg=THEME["text"], bg=THEME["card"]).pack(anchor="w")

        self.com_desc_lbl = tk.Label(com_card, text=self.t["com_desc"], font=("Segoe UI", 9),
                                     fg=THEME["text_muted"], bg=THEME["card"], justify=tk.LEFT)
        self.com_desc_lbl.pack(anchor="w", pady=(4, 6))

        com_f = tk.Frame(com_card, bg=THEME["card"])
        com_f.pack(fill=tk.X, pady=2)

        tk.Label(com_f, text=self.t["com_port_label"], font=("Segoe UI", 9),
                 fg=THEME["text"], bg=THEME["card"]).pack(side=tk.LEFT, padx=(0, 8))

        self.com_entry = tk.Entry(com_f, font=("Segoe UI", 10), bg="#151618",
                                  fg=THEME["text"], bd=1, relief="flat", width=12)
        self.com_entry.insert(0, self.bridge.symlink_path)
        self.com_entry.pack(side=tk.LEFT, ipady=2)

    def _build_tab_network_content(self):
        card = tk.Frame(self.tab_network, bg=THEME["card"], padx=14, pady=12,
                        highlightbackground=THEME["card_border"], highlightthickness=1)
        card.pack(fill=tk.X)

        row1 = tk.Frame(card, bg=THEME["card"])
        row1.pack(fill=tk.X, pady=4)

        tk.Label(row1, text=self.t["roaster_ip_label"], font=("Segoe UI", 9, "bold"),
                 fg=THEME["text"], bg=THEME["card"], width=16, anchor="w").pack(side=tk.LEFT)

        self.ip_entry = tk.Entry(row1, font=("Segoe UI", 10), bg="#151618",
                                 fg=THEME["text"], bd=1, relief="flat")
        self.ip_entry.insert(0, self.client.host or "")
        self.ip_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=3)

        row2 = tk.Frame(card, bg=THEME["card"])
        row2.pack(fill=tk.X, pady=4)

        tk.Label(row2, text=self.t["roaster_port_label"], font=("Segoe UI", 9, "bold"),
                 fg=THEME["text"], bg=THEME["card"], width=16, anchor="w").pack(side=tk.LEFT)

        self.port_entry = tk.Entry(row2, font=("Segoe UI", 10), bg="#151618",
                                   fg=THEME["text"], bd=1, relief="flat")
        self.port_entry.insert(0, str(self.client.port))
        self.port_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=3)

        # Action buttons
        btn_box = tk.Frame(card, bg=THEME["card"])
        btn_box.pack(fill=tk.X, pady=(10, 4))

        self.scan_btn = tk.Button(
            btn_box,
            text=self.t["scan_roaster"],
            font=("Segoe UI", 9, "bold"),
            bg="#2b2e38",
            fg=THEME["text"],
            activebackground=THEME["card_border"],
            bd=0,
            relief="flat",
            padx=12,
            pady=6,
            cursor="hand2",
            command=self._scan_roaster,
        )
        self.scan_btn.pack(side=tk.LEFT, padx=(0, 8))

        self.save_net_btn = tk.Button(
            btn_box,
            text=self.t["reconnect_btn"],
            font=("Segoe UI", 9, "bold"),
            bg=THEME["accent"],
            fg="#fff",
            activebackground=THEME["accent_hover"],
            bd=0,
            relief="flat",
            padx=14,
            pady=6,
            cursor="hand2",
            command=self._save_and_reconnect,
        )
        self.save_net_btn.pack(side=tk.LEFT)

        self.scan_status_lbl = tk.Label(card, text="", font=("Segoe UI", 9),
                                        fg=THEME["accent"], bg=THEME["card"])
        self.scan_status_lbl.pack(anchor="w", pady=(6, 0))

    def _build_tab_system_content(self):
        # Options
        opt_card = tk.Frame(self.tab_system, bg=THEME["card"], padx=14, pady=12,
                            highlightbackground=THEME["card_border"], highlightthickness=1)
        opt_card.pack(fill=tk.X, pady=(0, 10))

        cb_autostart = tk.Checkbutton(
            opt_card,
            text=self.t["autostart"],
            variable=self.autostart_var,
            font=("Segoe UI", 9),
            fg=THEME["text"],
            bg=THEME["card"],
            activebackground=THEME["card"],
            activeforeground=THEME["text"],
            selectcolor="#151618",
            command=self._toggle_autostart,
        )
        cb_autostart.pack(anchor="w", pady=2)

        cb_tray = tk.Checkbutton(
            opt_card,
            text=self.t["min_to_tray"],
            variable=self.min_to_tray_var,
            font=("Segoe UI", 9),
            fg=THEME["text"],
            bg=THEME["card"],
            activebackground=THEME["card"],
            activeforeground=THEME["text"],
            selectcolor="#151618",
        )
        cb_tray.pack(anchor="w", pady=2)

        # Web button
        if self.web:
            web_btn = tk.Button(
                opt_card,
                text="🌐 " + self.t["open_web"],
                font=("Segoe UI", 9, "bold"),
                bg="#2b2e38",
                fg=THEME["text"],
                activebackground=THEME["card_border"],
                bd=0,
                relief="flat",
                pady=6,
                cursor="hand2",
                command=lambda: webbrowser.open(f"http://localhost:{self.args.web_port}"),
            )
            web_btn.pack(fill=tk.X, pady=(8, 2))

        # Diagnostics Box
        diag_card = tk.Frame(self.tab_system, bg=THEME["card"], padx=14, pady=12,
                             highlightbackground=THEME["card_border"], highlightthickness=1)
        diag_card.pack(fill=tk.BOTH, expand=True)

        tk.Button(
            diag_card,
            text="⚡ " + self.t["run_diag"],
            font=("Segoe UI", 9, "bold"),
            bg=THEME["accent"],
            fg="#fff",
            activebackground=THEME["accent_hover"],
            bd=0,
            relief="flat",
            pady=6,
            cursor="hand2",
            command=self._run_diagnostics,
        ).pack(fill=tk.X, pady=(0, 8))

        self.diag_text = tk.Text(diag_card, bg="#151618", fg=THEME["text_muted"],
                                 font=("Consolas", 8), bd=0, height=8)
        self.diag_text.pack(fill=tk.BOTH, expand=True)

    def _build_footer(self):
        footer = tk.Frame(self.root, bg=THEME["bg"], padx=16, pady=4)
        footer.pack(fill=tk.X, side=tk.BOTTOM)

        tk.Label(footer, text="HB Roaster Wireless Bridge v1.2.0 · Open Source for Coffee Artisans",
                 font=("Segoe UI", 8), fg="#484d56", bg=THEME["bg"]).pack(side=tk.LEFT)

    def _setup_tray(self):
        try:
            import pystray
            from PIL import Image

            icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "AppIcon.ico")
            if os.path.exists(icon_path):
                img = Image.open(icon_path)
            else:
                img = Image.new("RGBA", (64, 64), (179, 123, 92, 255))

            menu = pystray.Menu(
                pystray.MenuItem(self.t["tray_show"], self._show_window, default=True),
                pystray.MenuItem(self.t["tray_web"], lambda: webbrowser.open(f"http://localhost:{self.args.web_port}")),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem(self.t["tray_exit"], self._exit_app),
            )
            self.tray_icon = pystray.Icon("HBRoasterBridge", img, "HB Roaster Bridge", menu)
            threading.Thread(target=self.tray_icon.run, daemon=True, name="TrayThread").start()
        except Exception as e:
            logger.debug("Pystray system tray not initialized: %s", e)

    def _show_window(self):
        self.root.after(0, self._restore_window)

    def _restore_window(self):
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def _on_close_window(self):
        if self.min_to_tray_var.get() and self.tray_icon is not None:
            self.root.withdraw()
        else:
            self._exit_app()

    def _exit_app(self):
        if self.tray_icon:
            try:
                self.tray_icon.stop()
            except Exception:
                pass
        if self.web:
            self.web.stop()
        self.bridge.stop()
        self.client.stop()
        self.root.destroy()
        sys.exit(0)

    def _copy_ws_url(self):
        ws_url = f"ws://127.0.0.1:{self.args.ws_port}/ws"
        self.root.clipboard_clear()
        self.root.clipboard_append(ws_url)
        messagebox.showinfo("HB Roaster", self.t["copied"])

    def _scan_roaster(self):
        self.scan_status_lbl.config(text=self.t["scanning"])
        self.scan_btn.config(state="disabled")

        def _worker():
            res = HBDiscovery.discover(timeout=3.0)
            def _done():
                self.scan_btn.config(state="normal")
                if res:
                    addr, dev_id = res
                    self.ip_entry.delete(0, tk.END)
                    self.ip_entry.insert(0, addr)
                    self.scan_status_lbl.config(text=self.t["found_roaster"].format(ip=f"{addr} ({dev_id})"))
                else:
                    self.scan_status_lbl.config(text=self.t["not_found"])
            self.root.after(0, _done)

        threading.Thread(target=_worker, daemon=True).start()

    def _save_and_reconnect(self):
        new_ip = self.ip_entry.get().strip()
        try:
            new_port = int(self.port_entry.get().strip())
        except ValueError:
            new_port = 16888

        self.client.host = new_ip
        self.client.port = new_port
        HBDiscovery.save_last_known_ip(new_ip)

        # Trigger reconnect
        threading.Thread(target=self.client._disconnect, daemon=True).start()
        self.scan_status_lbl.config(text=f"正在连接 {new_ip}:{new_port}...")

    def _toggle_autostart(self):
        WindowsAutoStart.set_enabled(self.autostart_var.get())

    def _run_diagnostics(self):
        self.diag_text.delete("1.0", tk.END)
        self.diag_text.insert(tk.END, self.t["diag_running"] + "\n\n")

        def _worker():
            lines = []
            ip = diagnose.get_local_wifi_ip()
            lines.append(f"1. 本机 IP 地址: {ip or '未知'}")

            is_vpn, tun = diagnose.check_vpn_status()
            lines.append(f"2. VPN / TUN 状态: {'检测到 ' + tun if is_vpn else '无'}")

            target = self.client.host
            if target:
                reachable = diagnose.test_tcp_port(target, self.client.port)
                lines.append(f"3. 烘焙机 TCP ({target}:{self.client.port}): {'通畅' if reachable else '无法连接'}")
            else:
                lines.append("3. 烘焙机目标: 尚未指定 IP")

            lines.append(f"4. Artisan 桥接: WebSocket 监听端口 {self.args.ws_port}")
            lines.append(f"5. Artisan 连接状态: {'活跃采集中' if self.bridge.artisan_connected else '未连接'}")

            res_text = "\n".join(lines)
            self.root.after(0, lambda: self.diag_text.insert(tk.END, res_text + "\n"))

        threading.Thread(target=_worker, daemon=True).start()

    def _cmd_power(self):
        cur = self.client.power_on
        new_state = not cur if cur is not None else True
        threading.Thread(target=lambda: self._safe_control(self.client.set_power, new_state), daemon=True).start()

    def _cmd_heat(self):
        cur = self.client.heat_on
        new_state = not cur if cur is not None else True
        title = self.t["confirm_heat_title"]
        msg = self.t["confirm_heat_on"] if new_state else self.t["confirm_heat_off"]
        if messagebox.askyesno(title, msg):
            threading.Thread(target=lambda: self._safe_control(self.client.set_heat, new_state), daemon=True).start()

    def _cmd_stir(self):
        cur = self.client.stir_on
        fan = self.client.fan_on or False
        new_state = not cur if cur is not None else True
        threading.Thread(target=lambda: self._safe_control(lambda s: self.client.set_cooling(stir=s, fan=fan), new_state), daemon=True).start()

    def _cmd_fan(self):
        cur = self.client.fan_on
        stir = self.client.stir_on or False
        new_state = not cur if cur is not None else True
        threading.Thread(target=lambda: self._safe_control(lambda f: self.client.set_cooling(stir=stir, fan=f), new_state), daemon=True).start()

    def _safe_control(self, func, arg):
        try:
            func(arg)
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("错误", f"指令执行失败: {e}"))

    def _toggle_language(self):
        self.lang = "en" if self.lang == "zh" else "zh"
        self.t = STRINGS[self.lang]
        self.lang_btn.config(text="EN" if self.lang == "zh" else "中文")
        self.title_lbl.config(text="☕ " + self.t["title"])
        self.subtitle_lbl.config(text=self.t["subtitle"])

        self.cards["bt"]["title"].config(text=self.t["bt"])
        self.cards["et"]["title"].config(text=self.t["et"])
        self.cards["ex"]["title"].config(text=self.t["ex"])
        self.cards["in"]["title"].config(text=self.t["in"])

        self.btn_power.config(text=self.t["power"])
        self.btn_heat.config(text=self.t["heat"])
        self.btn_stir.config(text=self.t["stir"])
        self.btn_fan.config(text=self.t["fan"])

        self.notebook.tab(0, text=self.t["tab_artisan"])
        self.notebook.tab(1, text=self.t["tab_network"])
        self.notebook.tab(2, text=self.t["tab_system"])

        self.ws_desc_lbl.config(text=self.t["ws_desc"])
        self.com_desc_lbl.config(text=self.t["com_desc"])
        self.scan_btn.config(text=self.t["scan_roaster"])
        self.save_net_btn.config(text=self.t["reconnect_btn"])

    def _periodic_update(self):
        # Update temperatures
        snap = self.client.temperature_snapshot()
        if snap:
            ex, ini, bt, et = snap
            self.cards["bt"]["val"].config(text=f"{bt:5.1f}")
            self.cards["et"]["val"].config(text=f"{et:5.1f}")
            self.cards["ex"]["val"].config(text=f"{ex:5.1f}")
            self.cards["in"]["val"].config(text=f"{ini:5.1f}")
        else:
            self.cards["bt"]["val"].config(text="--.-")
            self.cards["et"]["val"].config(text="--.-")
            self.cards["ex"]["val"].config(text="--.-")
            self.cards["in"]["val"].config(text="--.-")

        # Update roaster pill
        if self.client.is_connected:
            self.roaster_pill.config(text=f"● {self.t['roaster_online']} ({self.client.host})", fg=THEME["green"])
        else:
            self.roaster_pill.config(text=f"● {self.t['roaster_offline']}", fg=THEME["red"])

        # Update artisan pill
        if self.bridge.artisan_connected:
            self.artisan_pill.config(text=f"● {self.t['artisan_active']}", fg=THEME["green"])
        else:
            self.artisan_pill.config(text=f"● {self.t['artisan_waiting']}", fg=THEME["gray"])

        # Update control button highlights
        self._update_btn_state(self.btn_power, self.client.power_on)
        self._update_btn_state(self.btn_heat, self.client.heat_on)
        self._update_btn_state(self.btn_stir, self.client.stir_on)
        self._update_btn_state(self.btn_fan, self.client.fan_on)

        # Update system tray tooltip
        if self.tray_icon and snap:
            self.tray_icon.title = f"HB Roaster: BT {snap[2]:.1f}° | ET {snap[3]:.1f}°"

        self.root.after(300, self._periodic_update)

    def _update_btn_state(self, btn: tk.Button, state: Optional[bool]):
        if state is True:
            btn.config(bg=THEME["active_btn"], fg="#ffffff")
        elif state is False:
            btn.config(bg="#2b2e38", fg=THEME["text"])
        else:
            btn.config(bg="#1f2229", fg=THEME["text_muted"])


def run_app(args):
    if tk is None:
        print("Error: tkinter is not installed or available on this system.")
        sys.exit(1)
    root = tk.Tk()
    app = HBRoasterWindowsApp(root, args)
    root.mainloop()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="HB Roaster Windows GUI Application")
    parser.add_argument("--ip", type=str, default=None, help="Roaster IP")
    parser.add_argument("--port", type=int, default=16888, help="Roaster Port")
    parser.add_argument("--pty", type=str, default="COM11", help="COM port or PTY path")
    parser.add_argument("--ws-port", type=int, default=8088, help="Artisan WebSocket port")
    parser.add_argument("--no-ws", action="store_true", help="Disable WebSocket bridge")
    parser.add_argument("--web-port", type=int, default=8080, help="Web dashboard port")
    parser.add_argument("--no-web", action="store_true", help="Disable web dashboard")
    parser.add_argument("--debug", action="store_true", help="Debug logging")
    args = parser.parse_args()

    run_app(args)
